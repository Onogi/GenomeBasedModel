#include <Rcpp.h>
using namespace Rcpp;

/*
 Copyright (C) 2018 Akio Onogi

Released under the MIT license
http://opensource.org/licenses/mit-license.php
*/

//Caluculate the exponential of likelihood for line i.
double Loglikelihood(NumericVector output, NumericVector y, NumericVector ve, int ne, double missing, int nve, NumericVector residualgroup, NumericVector loglikelihoodvec)
{
  int	env;
  double loglikelihood = 0.0;

  for (env = 0; env < nve; ++env)
  {
    loglikelihoodvec(env) = 0.0;
  }
  for (env = 0; env < ne; ++env)
  {
    if (y(env) != missing)
    {
      loglikelihoodvec((int)residualgroup(env)) -= pow((y(env) - output(env)), 2.0);
    }
  }
  for (env = 0; env < nve; ++env)
  {
    loglikelihoodvec(env) *= (0.5 / ve(env));
    loglikelihood += loglikelihoodvec(env);
  }
  return(loglikelihood);
}

double Loglikelihood_nomissing(NumericVector output, NumericVector y, NumericVector ve, int ne, int nve, NumericVector residualgroup, NumericVector loglikelihoodvec)
{
  int	env;
  double loglikelihood = 0.0;

  for (env = 0; env < nve; ++env)
  {
    loglikelihoodvec(env) = 0.0;
  }
  for (env = 0; env < ne; ++env)
  {
    loglikelihoodvec((int)residualgroup(env)) -= pow((y(env) - output(env)), 2.0);
  }
  for (env = 0; env < nve; ++env)
  {
    loglikelihoodvec(env) *= (0.5 / ve(env));
    loglikelihood += loglikelihoodvec(env);
  }
  return(loglikelihood);
}

//log density of normal distribution
double	LogDensityNormalKernel(double v, double mu, double var)
{
  return(-0.5 * pow((v - mu), 2.0) / var);
}

//[[Rcpp::export]]
int ModelParameterInference(NumericMatrix Input, NumericVector Freevec, NumericMatrix Y, double Missing,
                            int Nl, int Ne, int Np, int Nr,
                            NumericMatrix SampledPara, NumericMatrix SampledVe,
                            NumericMatrix MeanOfPrior, NumericVector VarOfPrior, NumericVector Ve, int Nve, NumericVector Residualgroup,
                            NumericVector SdforParameters, NumericVector SdforVe, NumericVector Loglike,
                            int Burnin, int Thi, int Totalite, IntegerVector Order,
                            NumericVector Lowerlimit, NumericVector Upperlimit, NumericVector AccParameters, NumericVector AccVe, Function Model,
                            NumericVector NeNl, int Nmiss, NumericMatrix Missingposition, int Imputemissing, NumericVector Transformation,
                            NumericMatrix nRandom_para, NumericMatrix nRandom_ve, NumericMatrix uRandom_para, NumericMatrix uRandom_ve, NumericMatrix nRandom_miss)
{

  // For repeat statement
  int		mcmc, line, env, ii, para;

  // Model parameters
  NumericMatrix	Parameters(Np, Nl);

  // Output of the model
  NumericMatrix	Output_current(Ne,Nl), Output_proposed(Ne,Nl);

  // Sampling
  int		CumNs, CumNsab, DoSampling, AfterBurnin, Nsab;

  // MH update
  double	proposal, MHprob, Sd, Mu, Sigma, Proposedloglike, Currentloglike, temp;
  NumericVector  proposedpara(Np), currentpara(Np), ProposedloglikeVec(Nve), CurrentloglikeVec(Nve), Veloglikelihood(Nve), Temp(Ne);
  int   target, tf;

  // Initialization
  for (line = 0; line < Nl; ++line)
  {
    for (para = 0; para < Np; ++para)
    {
      Parameters(para, line) = nRandom_para(0, para * Nl + line) * sqrt(VarOfPrior(para)) + MeanOfPrior(para, line);
    }
    Temp = Model(Input(_,line), Freevec, Parameters(_, line));
    for(env = 0; env < Ne; ++env)
    {
      Output_current(env,line) = Temp (env);
    }
  }
  if (Imputemissing)
  {
    for (line = 0; line < Nmiss; ++line)
    {
      Y(Missingposition(line,0),Missingposition(line,1)) = Output_current(Missingposition(line,0),Missingposition(line,1)) +
        nRandom_miss(0, line) * sqrt(Ve(Residualgroup(Missingposition(line,0))));
    }
  }
  CumNs = -1;
  CumNsab = -1;
  Nsab = (Totalite - Burnin) / Thi;

  for (mcmc = 1; mcmc <= Totalite; ++mcmc)
  {
    //Sample or Not
    if (mcmc % Thi == 0)
    {
      DoSampling = 1; CumNs++;
    }
    else
    {
      DoSampling = 0;
    }
    if (DoSampling&&mcmc>Burnin)
    {
      AfterBurnin = 1; CumNsab++;
    }
    else
    {
      AfterBurnin = 0;
    }

    //Update of model parameters
    for (para = 0; para < Np; ++para)
    {
      for (env = 0; env < Nve; ++env)
      {
        Veloglikelihood(env) = 0.0;
      }
      for (line = 0; line < Nl; ++line)
      {
        target = Order(line);

        Sd = SdforParameters(para);
        Mu = MeanOfPrior(para, target);
        Sigma = VarOfPrior(para);
        for (ii = 0; ii < Np; ++ii)
        {
          currentpara(ii) = Parameters(ii, target);
          proposedpara(ii) = Parameters(ii, target);
        }

        MHprob = 0.0;
        proposedpara(para) = nRandom_para(mcmc, para * Nl + target) * Sd + currentpara(para);

        if(proposedpara(para)>Lowerlimit(para)&&proposedpara(para)<Upperlimit(para))
        {
          Temp = Model(Input(_,target), Freevec, proposedpara);
          for(env = 0; env < Ne; ++env)
          {
            Output_proposed(env,target) = Temp (env);
          }
          if(Imputemissing)
          {
            Currentloglike = Loglikelihood_nomissing(Output_current(_,target), Y(_,target), Ve, Ne, Nve, Residualgroup, CurrentloglikeVec);
            Proposedloglike = Loglikelihood_nomissing(Output_proposed(_,target), Y(_,target), Ve, Ne, Nve, Residualgroup, ProposedloglikeVec);
          }
          else
          {
            Currentloglike = Loglikelihood(Output_current(_,target), Y(_,target), Ve, Ne, Missing, Nve, Residualgroup, CurrentloglikeVec);
            Proposedloglike = Loglikelihood(Output_proposed(_,target), Y(_,target), Ve, Ne, Missing, Nve, Residualgroup, ProposedloglikeVec);
          }
          MHprob += Proposedloglike;
          MHprob -= Currentloglike;

          MHprob += LogDensityNormalKernel(proposedpara(para), Mu, Sigma);
          MHprob -= LogDensityNormalKernel(currentpara(para), Mu, Sigma);

          tf = (int)Transformation(para);
          switch (tf){
          case 1:
            MHprob += currentpara(para);
            MHprob -= proposedpara(para);
            break;
          case 2:
            temp = exp(proposedpara(para))/(1.0 + exp(proposedpara(para)));
            MHprob -= log((temp*(1-temp)));
            temp = exp(currentpara(para))/(1.0 + exp(currentpara(para)));
            MHprob += log((temp*(1-temp)));
            break;
          }

          if (MHprob>log(uRandom_para(mcmc-1, para * Nl + target)))
          {
            Parameters(para, target) = proposedpara(para);
            AccParameters(para) += 1.0;
            for (env = 0; env < Ne; ++env)
            {
              Output_current(env,target) = Output_proposed(env, target);
            }
            for (env = 0; env < Nve; ++env)
            {
              Veloglikelihood(env) += ProposedloglikeVec(env);
            }
          }
          else
          {
            if(para == Np - 1)
            {
              for (env = 0; env < Nve; ++env)
              {
                Veloglikelihood(env) += CurrentloglikeVec(env);
              }
            }
          }
        }
        else
        {
          if(para == Np - 1)
          {
            if(Imputemissing)
            {
              Currentloglike = Loglikelihood_nomissing(Output_current(_,target), Y(_,target), Ve, Ne, Nve, Residualgroup, CurrentloglikeVec);
            }
            else
            {
              Currentloglike = Loglikelihood(Output_current(_,target), Y(_,target), Ve, Ne, Missing, Nve, Residualgroup, CurrentloglikeVec);
            }
            for (env = 0; env < Nve; ++env)
            {
              Veloglikelihood(env) += CurrentloglikeVec(env);
            }
          }
        }

        if (AfterBurnin)
        {
          SampledPara(para * Nsab + CumNsab, target) = Parameters(para,target);
        }
      }
    }

    //Update of Ve
    for(env = 0; env<Nve; ++env)
    {
      proposal = nRandom_ve(mcmc-1, env) * SdforVe(env) + Ve(env);
      Currentloglike = Veloglikelihood(env) - 0.5 * NeNl(env) * log(Ve(env));
      if (proposal>0.0)
      {
        Proposedloglike = Veloglikelihood(env) * Ve(env) / proposal - 0.5 * NeNl(env) * log(proposal);

        MHprob = Proposedloglike - Currentloglike;
        MHprob -= log(proposal);
        MHprob += log(Ve(env));

        if (MHprob>log(uRandom_ve(mcmc-1, env)))
        {
          Ve(env) = proposal;
          AccVe(env) += 1.0;
          if (DoSampling) { Loglike(CumNs) = Proposedloglike; }
        }
        else
        {
          if (DoSampling) { Loglike(CumNs) = Currentloglike; }
        }
      }
      else
      {
        if (DoSampling) { Loglike(CumNs) = Currentloglike; }
      }
      if (AfterBurnin)
      {
        SampledVe(CumNsab,env) = Ve(env);
      }
    }

    //Update of missing Y
    if (Imputemissing)
    {
      for (line = 0; line < Nmiss; ++line)
      {
        Y(Missingposition(line,0),Missingposition(line,1)) = Output_current(Missingposition(line,0),Missingposition(line,1)) +
          nRandom_miss(mcmc, line) * sqrt(Ve(Residualgroup(Missingposition(line,0))));
      }
    }
  }	//mcmc

  return 0;
}
