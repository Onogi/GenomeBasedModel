#investigate computation time required for GenomeBasedModel

#Model function for GenomeBasedModel
SyntheticCurve<-function(input, freevec, parameters){
  #input is a matrix of (D * Np) * Ny specifying basis fuctions evaluated at sampling points
  #where D is the number of time points, Np is the number of parameters (or the number of basis functions),
  #and Ny is the number of samples.
  #freevec defines Np and D.
  #parameters is a matrix of Np * Ny.
  
  Np <- freevec[1] 
  D <- freevec[2]
  Ny <- ncol(input)
  
  output <- matrix(0, nrow=D, ncol=Ny)
  for(i in 1:Ny){
    output[, i] <- switch(as.character(Np),
                          "1" = parameters[1, i] * input[1:D, i],
                          "2" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i],
                          "3" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i],
                          "4" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i],
                          "5" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i],
                          "6" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i] + parameters[6, i] * input[(5*D+1):(6*D), i],
                          "7" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i] + parameters[6, i] * input[(5*D+1):(6*D), i] +
                            parameters[7, i] * input[(6*D+1):(7*D), i],
                          "8" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i] + parameters[6, i] * input[(5*D+1):(6*D), i] +
                            parameters[7, i] * input[(6*D+1):(7*D), i] + parameters[8, i] * input[(7*D+1):(8*D), i],
                          "9" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i] + parameters[6, i] * input[(5*D+1):(6*D), i] +
                            parameters[7, i] * input[(6*D+1):(7*D), i] + parameters[8, i] * input[(7*D+1):(8*D), i] + parameters[9, i] * input[(8*D+1):(9*D), i],
                          "10" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i] + parameters[6, i] * input[(5*D+1):(6*D), i] +
                            parameters[7, i] * input[(6*D+1):(7*D), i] + parameters[8, i] * input[(7*D+1):(8*D), i] + parameters[9, i] * input[(8*D+1):(9*D), i] +
                            parameters[10, i] * input[(9*D+1):(10*D), i],
                          "11" = parameters[1, i] * input[1:D, i] + parameters[2, i] * input[(D+1):(2*D), i] + parameters[3, i] * input[(2*D+1):(3*D), i] +
                            parameters[4, i] * input[(3*D+1):(4*D), i] + parameters[5, i] * input[(4*D+1):(5*D), i] + parameters[6, i] * input[(5*D+1):(6*D), i] +
                            parameters[7, i] * input[(6*D+1):(7*D), i] + parameters[8, i] * input[(7*D+1):(8*D), i] + parameters[9, i] * input[(8*D+1):(9*D), i] +
                            parameters[10, i] * input[(9*D+1):(10*D), i] + parameters[11, i] * input[(10*D+1):(11*D), i]
    )
  }
  
  output
}

#Basis functions for Legendre polynomials
LegendrePolynomial <- function(x, k){
  if(k==0){
    value = 1
  }else{
    if(k==1){
      value = x
    }else{
      value = ((2*k-1)*x*LegendrePolynomial(x, k-1)-(k-1)*LegendrePolynomial(x, k-2))/k
    }
  }
  value
}

SetBasis <- function(l, maxk){
  t <- length(l)
  minl <- min(l)
  maxl <- max(l)
  basis <- matrix(0, nrow=maxk + 1, ncol=t)
  scaledl <- as.numeric(t)
  
  scaledl = 2*(l-minl)/(maxl-minl)-1
  for(k in 0:maxk){
    for(j in 1:t){
      basis[k+1,j] = LegendrePolynomial(scaledl[j], k)
    }
  }
  basis
}

#test
Np<-11#10 degree Legendre polynomials
D<-100
Ny<-2
v <- matrix(as.vector(t(SetBasis(1:D, Np-1))), nrow=D * Np, ncol=Ny)
#Parameters for the first sample are all 1 and those for the second are all 0.1
w <- SyntheticCurve(v, c(Np, D), matrix(c(rep(1, Np), rep(0.1, Np)), ncol=Ny))
plot(w[, 1], type="o")
plot(w[, 2], type="o")
rm(v, w)


#Simulate data sets##############################################################
Ny <- c(50, 100, 150, 200, 250, seq(300, 1000, 100))
Np <- 1:11
P <- c(1000, 25000, 50000, 75000, 100000) 

#Heritability of parameters
h2 <- 0.8

#Number of QTLs
Nqtl <- 5

#Signal-noise ratio
SNratio <- 4

#Number of replications
Nsim <- 100

#Time points
L <- seq(-1, 1, 0.2)

#Influence of Ny####
library(GenomeBasedModel)
np <- 5
p <- 10000
Time.Ny_Matrix <- matrix(0, nr=length(Ny), nc=Nsim)
rownames(Time.Ny_Matrix) <- Ny

for(ny in Ny){
  for(sim in 1:Nsim){
    
    cat("====================\n")
    cat(ny, sim, "\n")
    cat("====================\n")
    
    Geno <- matrix(sample(c(-1, 0, 1), p*ny, replace=T, prob=c(0.25, 0.5, 0.25)), nrow=p, ncol=ny)
    B <- matrix(rnorm(Nqtl * np), nrow=Nqtl, ncol=np)
    Parameters <- t(t(Geno[1:Nqtl, ])%*%B)
    SD <- sqrt(apply(Parameters, 1, var) * (1-h2)/h2)
    Parameters <- Parameters + rnorm (np*ny, rep(0, np), SD)
    Freevec <- c(np, length(L))
    
    Input <- matrix(as.vector(t(SetBasis(L, np-1))), nrow=Freevec[2]*np, ncol=ny)
    
    Y <- SyntheticCurve(Input, Freevec, Parameters)
    SD <- sqrt(apply(Y, 1, var) * 1/(SNratio + 1))
    Y <- Y + rnorm (Freevec[2]*ny, rep(0, Freevec[2]), SD)
    
    Y <- rbind(1:ny, Y)
    Geno <- rbind(1:ny, Geno)
    
    start<-proc.time()
    Result<-GenomeBasedModel(Input=Input, Freevec=Freevec, Y=Y, Missing=999999, Np=np, Geno=Geno,
                             Methodcode=rep(4, np), Referencevalues=apply(Parameters, 1, mean),
                             Modelfunction=SyntheticCurve, Nite_GWR=100, Nloop=10, Nite_MPI_last=500, 
                             Tol=0, PassMatrix=TRUE)
    #By specifying Tol with 0, 
    #the number of iterations of GWR follow the predetermined value (100)
    end<-proc.time()
    Time.Ny_Matrix[as.character(ny), sim] <- (end[3]-start[3])/10
  }
}
write.csv(Time.Ny_Matrix, "Time.Ny_Matrix.csv")
write.csv(Time.Ny, "Time.Ny.csv")


#Influence of Np####
ny <- 200
p <- 10000
Time.Np_Matrix <- matrix(0, nr=length(Np), nc=Nsim)
rownames(Time.Np_Matrix) <- Np

for(np in Np){
  for(sim in 1:Nsim){
    
    cat("====================\n")
    cat(np, sim, "\n")
    cat("====================\n")
    
    Geno <- matrix(sample(c(-1, 0, 1), p*ny, replace=T, prob=c(0.25, 0.5, 0.25)), nrow=p, ncol=ny)
    B <- matrix(rnorm(Nqtl * np), nrow=Nqtl, ncol=np)
    Parameters <- t(t(Geno[1:Nqtl, ])%*%B)
    SD <- sqrt(apply(Parameters, 1, var) * (1-h2)/h2)
    Parameters <- Parameters + rnorm (np*ny, rep(0, np), SD)
    Freevec <- c(np, length(L))
    
    Input <- matrix(as.vector(t(SetBasis(L, np-1))), nrow=Freevec[2]*np, ncol=ny)
    
    Y <- SyntheticCurve(Input, Freevec, Parameters)
    SD <- sqrt(apply(Y, 1, var) * 1/(SNratio + 1))
    Y <- Y + rnorm (Freevec[2]*ny, rep(0, Freevec[2]), SD)
    
    Y <- rbind(1:ny, Y)
    Geno <- rbind(1:ny, Geno)
    
    start<-proc.time()
    Result<-GenomeBasedModel(Input=Input, Freevec=Freevec, Y=Y, Missing=999999, Np=np, Geno=Geno,
                             Methodcode=rep(4, np), Referencevalues=apply(Parameters, 1, mean),
                             Modelfunction=SyntheticCurve, Nite_GWR=100, Nloop=10, Nite_MPI_last=500, 
                             Tol=0, PassMatrix=TRUE)
    end<-proc.time()
    Time.Np_Matrix[as.character(np), sim] <- (end[3]-start[3])/10
  }
}
write.csv(Time.Np_Matrix, "Time.Np_Matrix.csv")
write.csv(Time.Np, "Time.Np.csv")


#Influence of P####
ny <- 200
np <- 5
Time.P_Matrix <- matrix(0, nr=length(P), nc=Nsim)
rownames(Time.P_Matrix) <- P

for(p in P){
  for(sim in 1:Nsim){
    
    cat("====================\n")
    cat(p, sim, "\n")
    cat("====================\n")
    
    Geno <- matrix(sample(c(-1, 0, 1), p*ny, replace=T, prob=c(0.25, 0.5, 0.25)), nrow=p, ncol=ny)
    B <- matrix(rnorm(Nqtl * np), nrow=Nqtl, ncol=np)
    Parameters <- t(t(Geno[1:Nqtl, ])%*%B)
    SD <- sqrt(apply(Parameters, 1, var) * (1-h2)/h2)
    Parameters <- Parameters + rnorm (np*ny, rep(0, np), SD)
    Freevec <- c(np, length(L))
    
    Input <- matrix(as.vector(t(SetBasis(L, np-1))), nrow=Freevec[2]*np, ncol=ny)
    
    Y <- SyntheticCurve(Input, Freevec, Parameters)
    SD <- sqrt(apply(Y, 1, var) * 1/(SNratio + 1))
    Y <- Y + rnorm (Freevec[2]*ny, rep(0, Freevec[2]), SD)
    
    Y <- rbind(1:ny, Y)
    Geno <- rbind(1:ny, Geno)
    
    start<-proc.time()
    Result<-GenomeBasedModel(Input=Input, Freevec=Freevec, Y=Y, Missing=999999, Np=np, Geno=Geno,
                             Methodcode=rep(4, np), Referencevalues=apply(Parameters, 1, mean),
                             Modelfunction=SyntheticCurve, Nite_GWR=100, Nloop=10, Nite_MPI_last=500, 
                             Tol=0, PassMatrix=TRUE)
    end<-proc.time()
    Time.P_Matrix[as.character(p), sim] <- (end[3]-start[3])/10
  }
}
write.csv(Time.P_Matrix, "Time.P_Matrix.csv")
write.csv(Time.P, "Time.P.csv")


#plot the results######################################################################
Time.Np.mean <- apply(Time.Np_Matrix, 1, mean)
Time.Np.sd <- apply(Time.Np_Matrix, 1, sd)
Time.Ny.mean <- apply(Time.Ny_Matrix, 1, mean)
Time.Ny.sd <- apply(Time.Ny_Matrix, 1, sd)
Time.P.mean <- apply(Time.P_Matrix, 1, mean)
Time.P.sd <- apply(Time.P_Matrix, 1, sd)

tiff("ComputationalTime.tiff", unit="cm", height=16, width=8, res=400)
par(mfrow=c(3,1))
par(mar=c(2,3,2,1))
par(mgp=c(2,1,0))

plot(Np, Time.Np.mean, type="o", xlab="", ylab="Time (s)", xlim=c(1,11), ylim=c(0, 30), xaxt="n", main="Number of parameters")
arrows(Np, Time.Np.mean, Np, Time.Np.mean + Time.Np.sd, angle=90, length=0.04)
arrows(Np, Time.Np.mean, Np, Time.Np.mean - Time.Np.sd, angle=90, length=0.04)
axis(1, at=1:11, labels=1:11)
text(8, 5, "Number of genotypes: 200", cex=0.8)
text(8.05, 3, "Number of markers: 10,000", cex=0.8)

plot(Ny, Time.Ny.mean, type="o", xlab="", ylab="Time (s)", xlim=range(Ny), ylim=c(0, 40), xaxt="n", main="Number of genotypes")
arrows(Ny, Time.Ny.mean, Ny, Time.Ny.mean + Time.Ny.sd, angle=90, length=0.04)
arrows(Ny, Time.Ny.mean, Ny, Time.Ny.mean - Time.Ny.sd, angle=90, length=0.04)
axis(1, at=Ny, labels=Ny)
text(700, 6,"Number of parameters: 5", cex=0.8)
text(720, 3,"Number of markers: 10,000", cex=0.8)

plot(P, Time.P.mean, type="o", xlab="", ylab="Time (s)", xlim=c(1000,100000), ylim=c(0, 50), xaxt="n", main="Number of markers")
arrows(P, Time.P.mean, P, Time.P.mean + Time.P.sd, angle=90, length=0.04)
arrows(P, Time.P.mean, P, Time.P.mean - Time.P.sd, angle=90, length=0.04)
axis(1, at=P, labels=c("1,000","25,000","50,000","75,000","100,000"))
text(70000, 10, "Number of parameters: 5", cex=0.8)
text(71000, 7, "Number of genotypes: 200", cex=0.8)

dev.off()
