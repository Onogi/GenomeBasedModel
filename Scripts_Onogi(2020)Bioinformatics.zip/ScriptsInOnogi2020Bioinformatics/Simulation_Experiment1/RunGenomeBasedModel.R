#Objects common among replications############################################
Sim <- 1:100
Point <- seq(0, 160, 20)
Freevec <- 0
Np <- 3
Missing <- 999999
Referencevalues <- c(100, 6, 0.05)
Sd <- c(20, 1.2, 0.01)
Nini <- 100#number of initial value vectors for Nelder-Meat optimization
Parametername <- c("A", "B", "K")


#Model function###############################################################
#For GenomeBasedModel
GompertzGrowthCurve<-function(input, freevec, parameters){
  #input is a vector specifying sampling points
  #freevec is ignored
  #parameters is a vector specifying A, B, and K
  A <- parameters[1]
  B <- parameters[2]
  K <- parameters[3]
  A*exp(-B*exp(-K*input))
}

#For the Nelder-Mead optimization of optim
GrowthCurve_optim <- function(parameters, input, freevec, y, missing){
  output <- GompertzGrowthCurve(input, freevec, parameters)
  use <- y != missing
  sum((y[use] - output[use])^2)
}


#Run GenomeBasedModel#########################################################
library(GenomeBasedModel)
Methodcode <- c(4, 4, 4)#Bayes C
Hyperpara <- list(list(Nu=5, S2=0.1, Kappa=0.001), list(Nu=5, S2=0.1, Kappa=0.001), list(Nu=5, S2=0.1, Kappa=0.001))

for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- rbind(1:ncol(Geno), Geno)
  
  Y <- t(as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1)))
  Y <- rbind(1:ncol(Y), Y)
  
  Input<-matrix(rep(Point, ncol(Y)), nr=length(Point))
  Result <- GenomeBasedModel(Input, Freevec, Y, Missing, Np, Geno, Methodcode, Referencevalues, GompertzGrowthCurve,
                             Residualgroup=1:length(Point), Hyperpara=Hyperpara)
  
  #Output the results
  for(para in 1:Np) {
    write.csv(Result$Para[[para]], paste("Sim", sim, ".GBM.para.", Parametername[para], ".csv", sep=""))
    Markereffects <- data.frame(Rho=Result$Genome[[para]]$Rho, Beta=Result$Genome[[para]]$Beta, Sd=Result$Genome[[para]]$Sd.beta)
    write.csv(Markereffects, paste("Sim", sim, ".GBM.genome.", Parametername[para], ".csv", sep=""))
  }
}


#Run optim and rrBLUP#############################################################
library(rrBLUP)
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  
  Y <- t(as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1)))
  Input<-matrix(rep(Point, ncol(Y)), nr=length(Point))
  
  Initialvalues <- NULL
  for(i in 1:Nini){
    Initialvalues <- rbind(Initialvalues, Referencevalues + rnorm(Np, 0, Sd))
  }
  Initialvalues[Initialvalues<=0] <- 1e-3
  
  Parameter <- matrix(0, ncol(Y), Np + 1)
  for(i in 1:ncol(Y)){
    #cat(i,"\n")
    temp <- matrix(0, Nini, Np + 1)
    for(j in 1:Nini){
      v <- try(optim(Initialvalues[j, ], GrowthCurve_optim, input=Input[, i], freevec=Freevec, y=Y[, i], missing=Missing,method="Nelder-Mead"))
      if(class(v) == "try-error"){
        temp[j, ] <- 1e+10
      }else{
        temp[j, 1] <- v$value
        temp[j, -1] <- v$par
      }
    }
    Parameter[i, ] <- temp[which.min(temp[, 1]), ]
  }
  colnames(Parameter) <- c("Value", Parametername)
  write.csv(Parameter, paste("Sim", sim, ".NM.para.csv", sep=""))
}

#Association mapping
#Extremely large values are often observed in B.
#two analyses were tested.
#genome1: use all values
#genome2: use values <= 100
library(VIGoR)
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  geno <- data.frame(Marker=1:nrow(Geno), Chr=0, Pos=0, Geno)
  Geno <- t(Geno)
  Parameter <- as.matrix(read.csv(paste("Sim", sim, ".NM.para.csv", sep=""), header=T, row.names=1))
  colnames(geno)[-c(1:3)] <- 1:nrow(Parameter)
  
  #Single locus test
  pheno <- data.frame(ID=1:nrow(Parameter), A=Parameter[, 2], B=Parameter[, 3], K=Parameter[, 4])
  Result <- GWAS(pheno, geno, min.MAF=0, plot=FALSE)
  write.csv(Result, paste("Sim", sim, ".NM.genome1.csv", sep=""))
  
  #Whole genome regression
  for(para in 1:Np){
    Result <- vigor(Parameter[, para + 1], Geno, Method="BayesC", Hyperparameters = c(5, 0.1, 0.001), Printinfo=FALSE)
    temp <- data.frame(Beta=Result$Beta, Sd.beta=Result$Sd.beta, Rho=Result$Rho)
    write.csv(temp, paste("Sim", sim, ".NMBayesC.genome1.", Parametername[para], ".csv", sep=""))
  }
  
  #remove values > 100 in B
  temp <- Parameter[, 3]
  temp[temp > 100] <- NA
  Parameter[, 3] <- temp
  
  #Single locus test
  pheno <- data.frame(ID=1:nrow(Parameter), A=Parameter[, 2], B=Parameter[, 3], K=Parameter[, 4])
  Result <- GWAS(pheno, geno, min.MAF=0, plot=FALSE)
  write.csv(Result, paste("Sim", sim, ".NM.genome2.csv", sep=""))
  
  #Whole genome regression
  for(para in 1:Np){
    Result <- vigor(Parameter[, para + 1], Geno, Method="BayesC", Hyperparameters = c(5, 0.1, 0.001), Printinfo=FALSE)
    temp <- data.frame(Beta=Result$Beta, Sd.beta=Result$Sd.beta, Rho=Result$Rho)
    write.csv(temp, paste("Sim", sim, ".NMBayesC.genome2.", Parametername[para], ".csv", sep=""))
  }
}


#Compare accuacy###########################################################################
#parameter estimates
rmse <- function(x, y){
  use <- (!is.na(x))&(!is.na(y))
  sqrt(mean((x[use] - y[use])^2))
}
Para.GBM <- matrix(NA, nr=length(Sim), nc=2 * Np)
Para.NM1 <- matrix(NA, nr=length(Sim), nc=6)
Para.NM2 <- matrix(NA, nr=length(Sim), nc=6)
colnames(Para.GBM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
colnames(Para.NM1) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
colnames(Para.NM2) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
for(sim in Sim){
  NMvalue <- read.csv(paste("Sim", sim, ".NM.para.csv", sep=""), header=T, row.names=1)

  for(para in Parametername){
    Truevalue <- as.matrix(read.csv(paste("Sim", sim, ".", para, ".csv", sep=""), header=T, row.names=1))
    
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".GBM.para.", para, ".csv", sep=""), header=T, row.names=1))
    GBMvalue <- apply(GBMvalue, 2, mean)
    Para.GBM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(GBMvalue, Truevalue), rmse(GBMvalue, Truevalue))
    Para.NM1[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(NMvalue[, para], Truevalue, use="pairwise.complete.obs"), rmse(NMvalue[, para], Truevalue))
  }
  
  #remove values > 100 in B
  NMvalue[, "B"][NMvalue[, "B"]>100] <- NA
  
  for(para in Parametername){
    Truevalue <- as.matrix(read.csv(paste("Sim", sim, ".", para, ".csv", sep=""), header=T, row.names=1))
    Para.NM2[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(NMvalue[, para], Truevalue, use="pairwise.complete.obs"), rmse(NMvalue[, para], Truevalue))
  } 
}

apply(Para.GBM, 2, mean)
#Cor.A       Cor.B       Cor.K       Rmse.A      Rmse.B      Rmse.K 
#0.905335437 0.730517032 0.817517796 1.471980367 0.938778507 0.004880358
apply(Para.NM1, 2, mean)
#Cor.A        Cor.B        Cor.K       Rmse.A       Rmse.B       Rmse.K 
#0.8203437 0.02805615 0.3594226e 2.397213 1660.568e 0.03029180
apply(Para.NM2, 2, mean)
#Cor.A     Cor.B     Cor.K    Rmse.A    Rmse.B    Rmse.K 
#0.8203437 0.2506496 0.3594226 2.3972127 9.9870994 0.0302918 

boxplot(Para.GBM[, 1:3], ylim=c(0, 1))
boxplot(Para.NM1[, 1:3], ylim=c(0, 1))
boxplot(Para.NM2[, 1:3], ylim=c(0, 1))
#=>Results of NM2 were reported in Onogi 2020.

#frequency of B>100
B100<-numeric(length(Sim))
for(sim in Sim){
  NMvalue <- read.csv(paste("Sim", sim, ".NM.para.csv", sep=""), header=T, row.names=1)
  B100[sim]<-sum(NMvalue[, "B"]>100)
}
mean(B100);sd(B100)
#11.85
#5.390555

#mean true values of B
TrueB<-matrix(0,400,length(Sim))
for(sim in Sim){
  temp <- read.csv(paste("Sim", sim, ".B.csv", sep=""), header=T, row.names=1)
  TrueB[,sim]<-unlist(temp)
}
mean(as.vector(TrueB));sd(as.vector(TrueB))
#5.937405
#1.400353


#Association mapping
#markers that are in LD with QTLs are regared as true positives.
#The threshold of LD (r2) is Thr;
Thr <- 0.8
library(ROCR)
Genome.GBM <- matrix(NA, nr=length(Sim), nc=Np)
Genome.NM1 <- matrix(NA, nr=length(Sim), nc=Np)
Genome.NM2 <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.GBM) <- Parametername
colnames(Genome.NM1) <- Parametername
colnames(Genome.NM2) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  NMvalue1 <- as.matrix(read.csv(paste("Sim", sim, ".NM.genome1.csv", sep=""), header=T, row.names=1))
  NMvalue2 <- as.matrix(read.csv(paste("Sim", sim, ".NM.genome2.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".MajorQTL.", para, ".csv",sep=""), header=T, row.names=1))
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".GBM.genome.", para, ".csv",sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(chr in 1:5){
      Range <- (MajorQTL[chr, 3] - 100):(MajorQTL[chr, 3] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[chr]] <- Which
    }
    
    ROCdata <- cbind(GBMvalue[, "Rho"], 0)
    for(chr in 1:5){
      ROCdata[RegardedAsTrue[[chr]][which.max(GBMvalue[RegardedAsTrue[[chr]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.GBM[sim, para] <- as.numeric(Auc.temp@y.values)
    
    ROCdata <- cbind(NMvalue1[, para], 0)
    for(chr in 1:5){
      ROCdata[RegardedAsTrue[[chr]][which.max(NMvalue1[RegardedAsTrue[[chr]], para])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.NM1[sim, para] <- as.numeric(Auc.temp@y.values)
    
    ROCdata <- cbind(NMvalue2[, para], 0)
    for(chr in 1:5){
      ROCdata[RegardedAsTrue[[chr]][which.max(NMvalue2[RegardedAsTrue[[chr]], para])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.NM2[sim, para] <- as.numeric(Auc.temp@y.values)
  }#para
}#sim


#associatin using BayesC after optimization with NM
Thr <- 0.8
library(ROCR)
Genome.NMBayesC1 <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.NMBayesC1) <- Parametername
Genome.NMBayesC2 <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.NMBayesC2) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".MajorQTL.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".NMBayesC.genome1.", para, ".csv",sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(chr in 1:5){
      Range <- (MajorQTL[chr, 3] - 100):(MajorQTL[chr, 3] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[chr]] <- Which
    }
    
    ROCdata <- cbind(NMvalue[, "Rho"], 0)
    for(chr in 1:5){
      ROCdata[RegardedAsTrue[[chr]][which.max(NMvalue[RegardedAsTrue[[chr]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.NMBayesC1[sim, para] <- as.numeric(Auc.temp@y.values)
    
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".NMBayesC.genome2.", para, ".csv",sep=""), header=T, row.names=1))
    ROCdata <- cbind(NMvalue[, "Rho"], 0)
    for(chr in 1:5){
      ROCdata[RegardedAsTrue[[chr]][which.max(NMvalue[RegardedAsTrue[[chr]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.NMBayesC2[sim, para] <- as.numeric(Auc.temp@y.values)
  }#para
}#sim

apply(Genome.GBM, 2, mean)
#0.9840842 0.9576690 0.9753675
apply(Genome.NM1, 2, mean)
#0.9958098 0.5097248 0.8870472
apply(Genome.NM2, 2, mean)
#0.9958098 0.7631633 0.8870472
apply(Genome.NMBayesC1, 2, mean)
#0.9833022 0.5019024 0.8234344
apply(Genome.NMBayesC2, 2, mean)
#0.9844404 0.7142614 0.8244020

boxplot(Genome.GBM, ylim=c(0.4, 1))
boxplot(Genome.NM1, ylim=c(0.4, 1))
boxplot(Genome.NM2, ylim=c(0.4, 1))
boxplot(Genome.NMBayesC1, ylim=c(0.4, 1))
boxplot(Genome.NMBayesC2, ylim=c(0.4, 1))


#plot#################################################################################
tiff("GrowthCurve_Para1.tiff", unit="cm", height=7, width=12, res=400)
par(mfrow=c(1, 2))
par(mar=c(3,2, 1.5, 0.5))
par(mgp=c(1.0, 0.5, 0))
temp <- cbind(Para.GBM[, 1], Para.NM1[, 1], Para.GBM[, 2], Para.NM1[, 2], Para.GBM[, 3], Para.NM1[, 3])
boxplot(temp, ylim=c(0, 1), xaxt="n", main="Correlation", ylab="", xlab="")
axis(1, at=1:6, paste(rep(c("A", "B", "K"), each=2), rep(c("JA", "IA"), 3), sep="_"), las=2)

Scale <- c(max(c(Para.GBM[, 4], Para.NM1[, 4])), max(c(Para.GBM[, 5], Para.NM1[, 5])), max(Para.GBM[, 6], Para.NM1[, 6]))
temp <- cbind(Para.GBM[, 4]/Scale[1], Para.NM1[, 4]/Scale[1],
              Para.GBM[, 5]/Scale[2], Para.NM1[, 5]/Scale[2],
              Para.GBM[, 6]/Scale[3], Para.NM1[, 6]/Scale[3])
boxplot(temp, ylim=c(0, 1), xaxt="n", main="RMSE", ylab="", xlab="")
axis(1, at=1:6, paste(rep(c("A", "B", "K"), each=2), rep(c("JA", "IA"), 3), sep="_"), las=2)
dev.off()


tiff("GrowthCurve_Genome1.tiff", unit="cm", height=8, width=12, res=400)
par(mar=c(4, 2, 1.5, 0.5))
par(mgp=c(1.0, 0.5, 0))
temp <- cbind(Genome.GBM[, 1], Genome.NMBayesC1[, 1], Genome.NM1[, 1],
              Genome.GBM[, 2], Genome.NMBayesC1[, 2], Genome.NM1[, 2],
              Genome.GBM[, 3], Genome.NMBayesC1[, 3], Genome.NM1[, 3])
boxplot(temp, ylim=c(0, 1), xaxt="n", main="AUC", ylab="", xlab="")
axis(1, at=1:9, paste(rep(c("A", "B", "K"), each=3), rep(c("JA   ", "IA-W", "IA-S "), 3), sep="_"), las=2)
dev.off()


tiff("GrowthCurve_Para2.tiff", unit="cm", height=7, width=12, res=400)
par(mfrow=c(1, 2))
par(mar=c(3, 2, 1.5, 0.5))
par(mgp=c(1.0, 0.5, 0))
temp <- cbind(Para.GBM[, 1], Para.NM2[, 1], Para.GBM[, 2], Para.NM2[, 2], Para.GBM[, 3], Para.NM2[, 3])
boxplot(temp, ylim=c(0, 1), xaxt="n", main="Correlation", ylab="", xlab="")
axis(1, at=1:6, paste(rep(c("A", "B", "K"), each=2), rep(c("JA", "IA"), 3), sep="_"), las=2)

Scale <-c(max(c(Para.GBM[, 4], Para.NM2[, 4])), max(c(Para.GBM[, 5], Para.NM2[, 5])), max(Para.GBM[, 6], Para.NM2[, 6]))
temp <- cbind(Para.GBM[, 4]/Scale[1], Para.NM2[, 4]/Scale[1],
              Para.GBM[, 5]/Scale[2], Para.NM2[, 5]/Scale[2],
              Para.GBM[, 6]/Scale[3], Para.NM2[, 6]/Scale[3])
boxplot(temp, ylim=c(0, 1), xaxt="n", main="RMSE", ylab="", xlab="")
axis(1, at=1:6, paste(rep(c("A", "B", "K"), each=2), rep(c("JA", "IA"), 3), sep="_"), las=2)
dev.off()


tiff("GrowthCurve_Genome2.tiff", unit="cm", height=8, width=12, res=400)
par(mar=c(4, 2, 1.5, 0.5))
par(mgp=c(1.0, 0.5, 0))
temp <- cbind(Genome.GBM[, 1], Genome.NMBayesC2[, 1], Genome.NM2[, 1],
              Genome.GBM[, 2], Genome.NMBayesC2[, 2], Genome.NM2[, 2],
              Genome.GBM[, 3], Genome.NMBayesC2[, 3], Genome.NM2[, 3])
boxplot(temp, ylim=c(0, 1), xaxt="n", main="AUC", ylab="", xlab="")
axis(1, at=1:9, paste(rep(c("A", "B", "K"), each=3), rep(c("JA   ", "IA-W", "IA-S "), 3), sep="_"), las=2)
dev.off()

