#Create data for experiment 1 (growth curve model)###############################################
#GENOME by Liang et al. 2007 is required (http://csg.sph.umich.edu/liang/genome/)
Nsim <- 100
N <- 400#200 individuals per subpopulation
History <- c("0 400 400", "1-1 2-1", "50 800")
writeLines(History, "Population.txt")#used as an input file of GENOME
Nchr <- 10#number of chromosomes
h2.para <- 0.9
h2.Y <- 0.6#signal noise ratio 1.5
Np <- 3#number of parameters
Parametername <- c("A", "B", "K")
Range <- list(c(90, 110), c(2, 10), c(0.03, 0.08))#ranges of parameter values
Gompertz <- function(t, A, B, K){A * exp(-B * exp(-K * t))}#growth curve
Point <- seq(0, 160, 20)#sampling points for growth curves

Nloci <- matrix(0, nrow=Nsim, ncol=Nchr)
Variance <- matrix(0, nrow=Nsim, ncol=Np * 3)
for(sim in 1:Nsim){
  
  #Genotype
  Geno.phased <- NULL
  for(chr in 1:Nchr){
    cat(sim, chr, "\n")
    
    Geno1 <- system(paste("genome -pop 2 ", N, " ", N, " -N Population.txt -c 1 -pieces 1000 -s 5000 -rec 0.001", sep=""), intern=T)
    Geno2 <- Geno1[(length(Geno1) - 2*N + 1):(length(Geno1))]
    Geno3 <- matrix(unlist(strsplit(Geno2, " ")), nr=2)[2, ]
    Geno4 <- matrix(as.numeric(unlist(strsplit(Geno3, ""))), nr=5000)
    cat(dim(Geno4), "\n")
    
    MAF.A <- rowSums(Geno4[, 1:N])/N
    MAF.A[MAF.A > 0.5] <- 1 - MAF.A[MAF.A > 0.5]
    MAF.B <- rowSums(Geno4[, (N+1):(2*N)])/N
    MAF.B[MAF.B > 0.5] <- 1 - MAF.B[MAF.B > 0.5]
    
    #use SNPs which are polymorphic in both populations
    #and use SNPs with MAF>0.05 in the entire population
    Common <- MAF.A>0&MAF.B>0&(MAF.A+MAF.B)>0.1
    Nloci[sim, chr] <- sum(Common)
    cat(Nloci[chr], "\n")
    
    Geno.phased <- rbind(Geno.phased, Geno4[Common,])
  }
  Nloci.cumsum <- cumsum(c(0, Nloci[sim, -Nchr]))
  Geno <- Geno.phased[, seq(1, 2*N, 2)] + Geno.phased[, seq(2, 2*N, 2)]
  write.csv(Geno, paste("Sim",sim,".Genotype.csv",sep=""))

  #Growth curve parameters
  #select 1 loci per chr from chr 1 to 5 as major QTLs
  #select 20 loci per chr as minor (background) QTLs
  Major <- as.list(numeric(Np))
  Minor <- as.list(numeric(Np))
  for(para in 1:Np){
    Major[para] <- list(NULL)
    Minor[para] <- list(NULL)
    for(chr in 1:Nchr){
      v <- sample(1:Nloci[sim, chr], 1)
      w <- sort(sample(c(1:Nloci[sim, chr])[-v], 20, replace=F))
      if(chr <= 5)
        Major[[para]] <- rbind(Major[[para]], c(chr, v, v + Nloci.cumsum[chr]))
      Minor[[para]] <- rbind(Minor[[para]], cbind(chr, w, w + Nloci.cumsum[chr]))
    }
    
    Major[[para]] <- cbind(Major[[para]], 0)
    for(i in 1:nrow(Major[[para]])){
      p <- sum(Geno[Major[[para]][i, 3], ])/(2 * N)
      a <- sqrt(1/(2 * p * (1-p))) * sample(c(-1, 1), 1)
      Major[[para]][i, 4] <- a
    }
    
    Minor[[para]] <- cbind(Minor[[para]], 0)
    for(i in 1:nrow(Minor[[para]])){
      p <- sum(Geno[Minor[[para]][i, 3], ])/(2 * N)
      a <- sqrt(0.02/(2 * p * (1 - p))) * sample(c(-1, 1), 1)
      Minor[[para]][i, 4] <- a
    }
    
    write.csv(Major[[para]], paste("Sim", sim, ".MajorQTL.", Parametername[para], ".csv", sep=""))
    write.csv(Minor[[para]], paste("Sim", sim, ".MinorQTL.", Parametername[para], ".csv", sep=""))
  }
  
  Para <- as.list(numeric(Np))
  for(para in 1:Np){
    v <- t(Geno[Major[[para]][,3], ]) %*% Major[[para]][, 4, drop=F]
    w <- t(Geno[Minor[[para]][,3], ]) %*% Minor[[para]][, 4, drop=F]
    U <- v + w
    E <- rnorm(nrow(U), 0, sqrt(var(U) * (1 - h2.para)/h2.para))
    Variance[sim, ((para-1) * 3 + 1):(para * 3)] <- c(var(v), var(w), var(E))
    
    temp <- as.numeric(U+E)
    temp <- temp - min(temp)
    Max <- max(temp)
    Para[[para]] <- temp/Max * (Range[[para]][2] - Range[[para]][1]) + Range[[para]][1]
    write.csv(Para[[para]], paste("Sim", sim, ".", Parametername[para], ".csv", sep=""))
  }

  #Phenotype
  Y.wn <- matrix(0, nr=N, nc=length(Point))
  for(i in 1:N){
    for(j in 1:length(Point)){
      Y.wn[i, j] <- Gompertz(Point[j], Para[[1]][i], Para[[2]][i], Para[[3]][i])
    }
  }
  Y <- Y.wn
  for(i in 1:length(Point)){
    Y[, i] <- Y.wn[, i] + rnorm(nrow(Y.wn), 0, sqrt(var(Y.wn[, i]) * (1 - h2.Y)/h2.Y))
  }
  write.csv(Y, paste("Sim", sim, ".Y.csv", sep=""))
}

#number of loci
mean(rowSums(Nloci));sd(rowSums(Nloci))
16421.88
166.608
#variance due to major QTLs
mean(c(Variance[, 1], Variance[, 4], Variance[, 7]));sd(c(Variance[, 1], Variance[, 4], Variance[, 7]))
5.290308
0.7966096
#variance due to minor (background) QTLs
mean(c(Variance[, 2], Variance[, 5], Variance[, 8]));sd(c(Variance[, 2], Variance[, 5], Variance[, 8]))
4.171004
0.6372865
#variance due to non-genetic errors
mean(c(Variance[, 3], Variance[, 6], Variance[, 9]));sd(c(Variance[, 3], Variance[, 6], Variance[, 9]))


#Fst caluculation############################################################################
library(adegenet)
library(hierfstat)

PairwiseFst <- numeric(Nsim)
for(sim in 1:Nsim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno[sort(sample(1:nrow(Geno),1000,replace=F)),]
  Geno[Geno==0] <- 1010
  Geno[Geno==1] <- 1020
  Geno[Geno==2] <- 2020
  
  Filename <- paste("Sim", sim, ".gen", sep="")
  write(sim, Filename)
  write(paste(paste("SNP", 1:nrow(Geno), sep=""), collapse=","), Filename, append=T)
  write("POP", Filename, append=T)
  
  Geno.temp <- apply(Geno, 2, paste, collapse=" ")
  Geno.temp <- rbind(paste(1:ncol(Geno),",",sep=""),Geno.temp)
  write(Geno.temp[, 1:(N/2)], Filename, append=T)
  write("POP", Filename, append=T)
  write(Geno.temp[, (N/2+1):N], Filename, append=T)
  
  Geno.genind <- import2genind(file=Filename)
  PairwiseFst[sim] <- pairwise.fst(Geno.genind)
}
hist(PairwiseFst)
mean(PairwiseFst);sd(PairwiseFst)
0.05847131
0.003525117


#Example of genome-wide LD pattern#######################################################
#use the last chromosome
sim
100
chr
10
sum(Common)
1682
dim(Geno4)
#5000 800

Geno5 <- Geno4[Common, seq(1, 2*N, 2)] + Geno4[Common, seq(2, 2*N, 2)]
LD <- cor(t(Geno5))^2

library(viridis)
jet.colors <- colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan",
                                 "white", "yellow", "#FF7F00", "red", 
                                 "#7F0000"))
Col.jet <- jet.colors(25)[-c(1:13)]

tiff("LDexample.tiff", unit="cm", height=8, width=8, res=200)
par(mar=c(0.5, 0.5, 0.5, 0.5))
image(LD, breaks=seq(0, 1, length.out=13), col=Col.jet, main="", xlab="", ylab="", xaxt="n", yaxt="n")
box()
dev.off()

