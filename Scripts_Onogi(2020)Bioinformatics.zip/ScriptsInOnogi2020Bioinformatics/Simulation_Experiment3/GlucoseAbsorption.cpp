#include <Rcpp.h>
using namespace Rcpp;

//Glucose absorption model by Dalla Man C. et al. (2006)

double delta_qsto1 (double k21, double qsto1, double D){
  return -1.0 * k21 * qsto1 + D;
//D is added only when t=0
}

double delta_qsto2 (double kempt, double qsto2, double k21, double qsto1){
  return -1.0 * kempt * qsto2 + k21 * qsto1;
}

double delta_qgut (double kabs, double qgut, double kempt, double qsto2){
  return -1.0 * kabs * qgut + kempt * qsto2;
}

// [[Rcpp::export]]
NumericVector GlucoseAbsorption_cpp(NumericVector input, NumericVector freevec, NumericVector para) {

  double D, Width;
  int Ns;
  double kempt, kabs, f;
  double qsto1_ini, qsto2_ini, qgut_ini;
  double qsto1, qsto2, qgut;
  double qsto1_new, qsto2_new, qgut_new;
  double t;
  int s;
  
  D = freevec(0);
  Width = freevec(1);
  Ns = (int) freevec(2);
  
  kempt = exp(para(0))/(1 + exp(para(0)));//parameter a in Onogi 2020
  kabs = exp(para(1))/(1 + exp(para(1)));//parameter b in Onogi 2020
  f = 1.0;
  
  NumericVector SampledRa(Ns);
  s = 0;
  
  t = 0.0;
  qsto1_ini = 0.0;
  qsto2_ini = 0.0;
  qgut_ini = 0.0;
  
  t = Width;
  qsto1 = qsto1_ini + Width * delta_qsto1(kempt, qsto1_ini, D);
  qsto2 = qsto2_ini + Width * delta_qsto2(kempt, qsto2_ini, kempt, qsto1_ini);
  qgut = qgut_ini + Width * delta_qgut(kabs, qgut_ini, kempt, qsto2_ini);

  do {
    t += Width;
    qsto1_new = qsto1 + Width * delta_qsto1(kempt, qsto1, 0.0);
    qsto2_new = qsto2 + Width * delta_qsto2(kempt, qsto2, kempt, qsto1);
    qgut_new = qgut + Width * delta_qgut(kabs, qgut, kempt, qsto2);
    qsto1 = qsto1_new;
    qsto2 = qsto2_new;
    qgut = qgut_new;
    
    if(t == input(s)){
      SampledRa(s) = f * kabs * qgut;
      s++;
    }
  } while (t < input(Ns - 1));

  return SampledRa;
}
