#Create marker genotypes for experiment 3 (glucose absorption)
#GENOME by Liang et al. 2007 is required (http://csg.sph.umich.edu/liang/genome/)
Nsim <- 100
N <- 200
Nchr <- 22
Nloci <- matrix(0, nrow=Nsim, ncol=Nchr)
for(sim in 1:Nsim){
  
  Geno.phased <- NULL
  for(chr in 1:Nchr){
    cat(sim, chr, "\n")
    
    Geno1 <- system(paste("genome -pop 1 ", 2*N, "-c 1 -pieces 10000 -s 10000 -rec 0.0001", sep=""), intern=T)
    Geno2 <- Geno1[(length(Geno1) - 4*N + 1):(length(Geno1))]
    Geno3 <- apply(cbind(Geno2[seq(1, 4*N, 2)], Geno2[seq(2, 4*N, 2)]), 1, paste, collapse="")
    Geno3 <- matrix(unlist(strsplit(Geno3, " ")), nr=2)[2, ]
    Geno4 <- matrix(as.numeric(unlist(strsplit(Geno3, ""))), nr=10000)
    cat(dim(Geno4), "\n")
    
    MAF <- rowSums(Geno4)/(2*N)
    MAF[MAF > 0.5] <- 1 - MAF[MAF > 0.5]
    
    #use SNPs with MAF>0.05
    Common <- MAF>0.05
    Nloci[sim, chr] <- sum(Common)
    cat(Nloci[sim, chr], "\n")
    
    Geno.phased <- rbind(Geno.phased, Geno4[Common,])
  }
  Nloci.cumsum <- cumsum(c(0, Nloci[sim, -Nchr]))
  Geno <- Geno.phased[, seq(1, 2*N, 2)] + Geno.phased[, seq(2, 2*N, 2)]
  write.csv(Geno, paste("Sim",sim,".Genotype.csv",sep=""))
}

#count the number of markers
Nm <- numeric(Nsim)
for(sim in 1:Nsim){
  cat(sim,"\n")
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Nm[sim] <- nrow(Geno)
}
mean(Nm);sd(Nm)
89742.61
304.206
