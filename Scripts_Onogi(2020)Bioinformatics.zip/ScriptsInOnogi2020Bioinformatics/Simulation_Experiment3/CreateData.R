#Simulate glucose absorption using the model by Dalla Man C. et al. (2006)########################
#genotype data was simulated using CreateGenotype.R

#Model parameter names
Gpara <- c("kempt", "kabs")
#In Onogi 2020, these parameters are named as a and b, respectively.

#values from Dalla Man C. et al. (2006)
Referencevalue <- list(kempt=0.222, kabs=0.013)
Referencevalue <- unlist(Referencevalue)
Referencevalue <- log(Referencevalue/(1-Referencevalue))#transformation

#check sensitivity of model parameters
Rcpp::sourceCpp("GlucoseAbsorption.cpp")
Samplingpoint <- c(5,10,15,20,30,40,50,60,75,90,120,150,180,210,240,260,280,300,360,420)
Input <- matrix(Samplingpoint, nr=length(Samplingpoint), nc=1)
Freevec <- c(75000, 1, 20)
Para <- Referencevalue

Nrandom <- 200
Range <- as.list(numeric(length(Gpara)))
names(Range) <- Gpara 
Range[["kempt"]] <- c(0.05, 0.5)
Range[["kempt"]] <- log(Range[["kempt"]]/(1-Range[["kempt"]]))
Range[["kabs"]] <- c(0.01, 0.03)
Range[["kabs"]] <- log(Range[["kabs"]]/(1-Range[["kabs"]]))
for(para in Gpara){
  cat("#",para,"\n")
  
  s <- Range[[para]]
  value <- matrix(rep(Referencevalue, each=Nrandom), nc=length(Gpara))
  colnames(value) <- Gpara
  value[, para] <- runif(Nrandom, s[1], s[2])
  Sample <- NULL
  for(r in 1:Nrandom){
    v <- GlucoseAbsorption_cpp(Input[,1], Freevec, value[r, ])
    Sample <- rbind(Sample, v)
  }
  cat("#", sum(apply(Sample, 2, var)), "\n")
}
# kempt 
# 261460.2 
# kabs 
# 283638.6 

h2.para <- 0.8#heritability of model parameters
h2.obs <- 0.8#signal noise ratio 4
Np <- length(Gpara)
Nqtl <- 5
Tmax <- 420
Samplingpoint <- c(5,10,15,20,30,40,50,60,75,90,120,150,180,210,240,260,280,300,360,420)

Nsim <- 100
Lowerbound <- 1e-3
for(sim in 1:Nsim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Nm <- nrow(Geno)
  N <- ncol(Geno)
  
  QTL <- as.list(numeric(Np))
  names(QTL) <- Gpara
  for(para in Gpara){
    Pos <- sort(sample(1:Nm, Nqtl, replace=F))
    Af <- rowSums(Geno[Pos, ])/(2 * N)
    QTL[[para]] <- cbind(Pos, sqrt(1/(2 * Af * (1 - Af))) * sample(c(-1, 1), Nqtl, replace=T))
    write.csv(QTL[[para]], paste("Sim", sim, ".QTL.", para, ".csv", sep=""))
  }
  
  Para <- as.list(numeric(Np))
  names(Para) <- Gpara
  for(para in Gpara){
    U <- t(Geno[QTL[[para]][, 1], ])%*%QTL[[para]][, 2, drop=F]
    E <- rnorm(nrow(U), 0, sqrt(var(U) * (1 - h2.para)/h2.para))
    
    temp <- as.numeric(U + E)
    temp <- temp - min(temp)
    Max <- max(temp)
    Para[[para]] <- temp/Max * (Range[[para]][2] - Range[[para]][1]) + Range[[para]][1]
    write.csv(Para[[para]], paste("Sim", sim, ".", para, ".csv", sep=""))
  }
  
  #create observed data
  Y <- matrix(0, nr=length(Samplingpoint), nc=N)
  Input<-matrix(Samplingpoint,nr=length(Samplingpoint),nc=N)
  for(line in 1:N){
    temp <- GlucoseAbsorption_cpp(Input[,line], Freevec, c(Para[["kempt"]][line],Para[["kabs"]][line]))
    Y[, line] <- temp
  }
  for(s in 1:length(Samplingpoint)){
    v <- var(Y[s, ]) * (1-h2.obs)/h2.obs
    Noise <- rnorm(N, 0, sqrt(v))
    w <- Y[s, ] + Noise
    w[w < Lowerbound] <- Lowerbound
    Y[s, ] <- w
  }
  
  write.csv(Y, paste("Sim", sim, ".Y.csv", sep=""))
}
