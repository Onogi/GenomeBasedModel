#Objects common among replications############################################
Sim <- 1:100
Tmax <- 420
Samplingpoint <- c(5,10,15,20,30,40,50,60,75,90,120,150,180,210,240,260,280,300,360,420)
N <- 200
Np <- 2
Missing <- 999999
#values from Dalla Man C. et al. (2006)
Referencevalue <- list(kempt=0.222, kabs=0.013)
Referencevalue <- unlist(Referencevalue)
Referencevalue <- log(Referencevalue/(1-Referencevalue))
Input <- matrix(Samplingpoint, nr=length(Samplingpoint), nc=N)
Freevec <- list(D=75000, Width=1, Ns=nrow(Input))
Freevec <- unlist(Freevec)

Parametername <- c("kempt", "kabs")#a and b in Onogi 2020, respectively
Range <- as.list(numeric(Np))#used to generate initial values for NM optimization
names(Range) <- Parametername
Range[["kempt"]] <- c(0.05,0.5)
Range[["kempt"]] <- log(Range[["kempt"]]/(1-Range[["kempt"]]))
Range[["kabs"]] <- c(0.01, 0.03)
Range[["kabs"]] <- log(Range[["kabs"]]/(1-Range[["kabs"]]))
Nini <- 100#number of initial vectors of NM optimization


#Model function###############################################################
#For GenomeBasedModel
Rcpp::sourceCpp("GlucoseAbsorption.cpp")

#For the Nelder-Mead optimization of optim
GlucoseAbsorption_optim <- function(parameters, input, freevec, y, missing){
  output <- GlucoseAbsorption_cpp(input, freevec, parameters)
  use <- y != missing
  sum((y[use] - output[use])^2)
}


#Run GenomeBasedModel#########################################################
library(GenomeBasedModel)
Methodcode <- c(4, 4)#Bayes C and normal priors
Hyperpara <- list(list(Nu=5, S2=0.1, Kappa=0.001), 
                  list(Nu=5, S2=0.1, Kappa=0.001))

for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- rbind(1:ncol(Geno), Geno)
  
  Y <- as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1))
  Y <- rbind(1:ncol(Y), Y)

  SdforVe<-abs(apply(Y[-1,], 1, mean))*0.2
  Result <- GenomeBasedModel(Input, Freevec, Y, Missing, Np, Geno, Methodcode, Referencevalue, GlucoseAbsorption_cpp, 
                             Hyperpara=Hyperpara, Residualgroup=1:Freevec[3],
                             Transformation=c("logit", "logit"),
                             SdforParameters=c(0.4, 0.1), SdforVe=SdforVe)

  for(para in 1:Np) {
    write.csv(Result$Para[[para]], paste("Sim", sim, ".GBM.para.", Parametername[para], ".csv", sep=""))
    Markereffects <- data.frame(Rho=Result$Genome[[para]]$Rho, Beta=Result$Genome[[para]]$Beta, Sd=Result$Genome[[para]]$Sd.beta)
    write.csv(Markereffects, paste("Sim", sim, ".GBM.genome.", Parametername[para], ".csv", sep=""))  
  }
}

#Reduce sampling points
#one-half
Input2 <- Input[seq(1, nrow(Input), 2), ]
Freevec2 <- Freevec
Freevec2["Ns"] <- 10
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- rbind(1:ncol(Geno), Geno)
  
  Y <- as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1))
  Y <- Y[seq(1,nrow(Input),2), ]
  Y <- rbind(1:ncol(Y), Y)

  SdforVe <- abs(apply(Y[-1, ], 1, mean))*0.2
  Result <- GenomeBasedModel(Input2, Freevec2, Y, Missing, Np, Geno, Methodcode, Referencevalue, GlucoseAbsorption_cpp, 
                             Hyperpara=Hyperpara, Residualgroup=1:Freevec2[3],
                             Transformation=c("logit", "logit"),
                             SdforParameters=c(0.4, 0.1), SdforVe=SdforVe)

  for(para in 1:Np) {
    write.csv(Result$Para[[para]], paste("Sim", sim, ".OneHalf.GBM.para.", Parametername[para], ".csv", sep=""))
    Markereffects <- data.frame(Rho=Result$Genome[[para]]$Rho, Beta=Result$Genome[[para]]$Beta, Sd=Result$Genome[[para]]$Sd.beta)
    write.csv(Markereffects, paste("Sim", sim, ".OneHalf.GBM.genome.", Parametername[para], ".csv", sep="")) 
  }
}

#OneFourth
Input4 <- Input[c(1,3,7,13,20), ]
Freevec4 <- Freevec
Freevec4["Ns"] <- 5
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- rbind(1:ncol(Geno), Geno)
  
  Y <- as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1))
  Y <- Y[c(1,3,7,13,20), ]
  Y <- rbind(1:ncol(Y), Y)
  
  SdforVe<-abs(apply(Y[-1,],1,mean))*0.2
  Result <- GenomeBasedModel(Input4, Freevec4, Y, Missing, Np, Geno, Methodcode, Referencevalue, GlucoseAbsorption_cpp, 
                             Hyperpara=Hyperpara, Residualgroup=1:Freevec4[3],
                             Transformation=c("logit", "logit"),
                             SdforParameters=c(0.4, 0.1), SdforVe=SdforVe)

  for(para in 1:Np) {
    write.csv(Result$Para[[para]], paste("Sim", sim, ".OneFourth.GBM.para.", Parametername[para], ".csv", sep=""))
    Markereffects <- data.frame(Rho=Result$Genome[[para]]$Rho, Beta=Result$Genome[[para]]$Beta, Sd=Result$Genome[[para]]$Sd.beta)
    write.csv(Markereffects, paste("Sim", sim, ".OneFourth.GBM.genome.", Parametername[para], ".csv", sep="")) 
  }
}


#Run optim and t.test#############################################################
library(rrBLUP)
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  
  Y <- as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1))
  
  Initialvalues<-cbind(runif(Nini, Range[["kempt"]][1], Range[["kempt"]][2]), 
                       runif(Nini, Range[["kabs"]][1], Range[["kabs"]][2]))
  
  Parameter <- matrix(0, ncol(Y), Np + 1)
  for(i in 1:ncol(Y)){
    #cat(i,"\n")
    temp <- matrix(0, Nini, Np + 1)
    for(j in 1:Nini){
      v <- try(optim(Initialvalues[j, ], GlucoseAbsorption_optim, input=Input[, i], freevec=Freevec, y=Y[, i], missing=Missing,method="Nelder-Mead"))
      if(class(v) == "try-error"){
        temp[j, ] <- 1e+10
      }else{
        temp[j, 1] <- v$value
        temp[j, -1] <- v$par
      }
    }
    Parameter[i, ] <- temp[which.min(temp[, 1]), ]
  }
  colnames(Parameter) <- c("Value", Parametername)
  write.csv(Parameter, paste("Sim", sim, ".NM.para.csv", sep=""))
}

#One-half
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  
  Y <- as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1))
  Y <- Y[seq(1,nrow(Input),2), ]
  
  Initialvalues<-cbind(runif(Nini, Range[["kempt"]][1], Range[["kempt"]][2]), 
                       runif(Nini, Range[["kabs"]][1], Range[["kabs"]][2]))
  
  Parameter <- matrix(0, ncol(Y), Np + 1)
  for(i in 1:ncol(Y)){
    #cat(i,"\n")
    temp <- matrix(0, Nini, Np + 1)
    for(j in 1:Nini){
      v <- try(optim(Initialvalues[j, ], GlucoseAbsorption_optim, input=Input2[, i], freevec=Freevec2, y=Y[, i], missing=Missing,method="Nelder-Mead"))
      if(class(v) == "try-error"){
        temp[j, ] <- 1e+10
      }else{
        temp[j, 1] <- v$value
        temp[j, -1] <- v$par
      }
    }
    Parameter[i, ] <- temp[which.min(temp[, 1]), ]
  }
  colnames(Parameter) <- c("Value", Parametername)
  write.csv(Parameter, paste("Sim", sim, ".OneHalf.NM.para.csv", sep=""))
}

#One-fourth
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  
  Y <- as.matrix(read.csv(paste("Sim", sim, ".Y.csv", sep=""), header=T, row.names=1))
  Y <- Y[c(1,3,7,13,20), ]
  
  Initialvalues<-cbind(runif(Nini, Range[["kempt"]][1], Range[["kempt"]][2]), 
                       runif(Nini, Range[["kabs"]][1], Range[["kabs"]][2]))
  
  Parameter <- matrix(0, ncol(Y), Np + 1)
  for(i in 1:ncol(Y)){
    #cat(i,"\n")
    temp <- matrix(0, Nini, Np + 1)
    for(j in 1:Nini){
      v <- try(optim(Initialvalues[j, ], GlucoseAbsorption_optim, input=Input4[, i], freevec=Freevec4, y=Y[, i], 
                     missing=Missing,method="Nelder-Mead"))
      if(class(v) == "try-error"){
        temp[j, ] <- 1e+10
      }else{
        temp[j, 1] <- v$value
        temp[j, -1] <- v$par
      }
    }
    Parameter[i, ] <- temp[which.min(temp[, 1]), ]
  }
  colnames(Parameter) <- c("Value", Parametername)
  write.csv(Parameter, paste("Sim", sim, ".OneFourth.NM.para.csv", sep=""))
}

#Association mapping
library(VIGoR)
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- t(Geno)
  Parameter <- as.matrix(read.csv(paste("Sim", sim, ".NM.para.csv", sep=""), header=T, row.names=1))
  
  for(i in 1:Np){
    Result.NM.single <- numeric(ncol(Geno))
    for(m in 1:ncol(Geno)){
      Y.sd <- as.vector(scale(Parameter[, i+1]))
      temp <- lm(Y.sd ~ Geno[,m])
      Result.NM.single[m] <- log10(summary(temp)[[4]][2,4])*(-1)
    }
    write.csv(Result.NM.single,paste("Sim",sim,".NM.genome.",Parametername[i],".csv",sep=""))
  }
  
  for(para in 1:Np){
    Result.NM <- vigor(Parameter[, para + 1], Geno, Method="BayesC", Hyperparameters = c(5, 0.1, 0.001), Printinfo=FALSE)
    temp <- data.frame(Beta=Result.NM$Beta, Sd.beta=Result.NM$Sd.beta, Rho=Result.NM$Rho)
    write.csv(temp, paste("Sim", sim, ".NMBayesC.genome.", Parametername[para], ".csv", sep=""))
  }
}

#One-half
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- t(Geno)
  Parameter <- as.matrix(read.csv(paste("Sim", sim, ".OneHalf.NM.para.csv", sep=""), header=T, row.names=1))
  
  for(i in 1:Np){
    Result.NM.single <- numeric(ncol(Geno))
    for(m in 1:ncol(Geno)){
      Y.sd <- as.vector(scale(Parameter[, i+1]))
      temp <- lm(Y.sd ~ Geno[,m])
      Result.NM.single[m] <- log10(summary(temp)[[4]][2,4])*(-1)
    }
    write.csv(Result.NM.single,paste("Sim",sim,".OneHalf.NM.genome.",Parametername[i],".csv",sep=""))
  }
  
  for(para in 1:Np){
    Result.NM <- vigor(Parameter[, para + 1], Geno, Method="BayesC", Hyperparameters = c(5, 0.1, 0.001), Printinfo=FALSE)
    temp <- data.frame(Beta=Result.NM$Beta, Sd.beta=Result.NM$Sd.beta, Rho=Result.NM$Rho)
    write.csv(temp, paste("Sim", sim, ".OneHalf.NMBayesC.genome.", Parametername[para], ".csv", sep=""))
  }
}

#One-fourth
for(sim in Sim){
  cat(sim,"\n")
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  Geno <- Geno-1
  Geno <- t(Geno)
  Parameter <- as.matrix(read.csv(paste("Sim", sim, ".OneFourth.NM.para.csv", sep=""), header=T, row.names=1))
  
  for(i in 1:Np){
    Result.NM.single <- numeric(ncol(Geno))
    for(m in 1:ncol(Geno)){
      Y.sd <- as.vector(scale(Parameter[, i+1]))
      temp <- lm(Y.sd ~ Geno[,m])
      Result.NM.single[m] <- log10(summary(temp)[[4]][2,4])*(-1)
    }
    write.csv(Result.NM.single,paste("Sim",sim,".OneFourth.NM.genome.",Parametername[i],".csv",sep=""))
  }
  
  for(para in 1:Np){
    Result.NM <- vigor(Parameter[, para + 1], Geno, Method="BayesC", Hyperparameters = c(5, 0.1, 0.001), Printinfo=FALSE)
    temp <- data.frame(Beta=Result.NM$Beta, Sd.beta=Result.NM$Sd.beta, Rho=Result.NM$Rho)
    write.csv(temp, paste("Sim", sim, ".OneFourth.NMBayesC.genome.", Parametername[para], ".csv", sep=""))
  }
}


#Retrieve results#####################################################################
#parameter estimates
rmse <- function(x, y){
  use <- (!is.na(x))&(!is.na(y))
  sqrt(mean((x[use] - y[use])^2))
}
Para.GBM <- matrix(NA, nr=length(Sim), nc=2 * Np)
Para.NM <- matrix(NA, nr=length(Sim), nc=2 * Np)
colnames(Para.GBM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
colnames(Para.NM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))

for(sim in Sim){
  NMvalue <- read.csv(paste("Sim", sim, ".NM.para.csv", sep=""), header=T, row.names=1)

  for(para in Parametername){
    Truevalue <- as.matrix(read.csv(paste("Sim", sim, ".", para, ".csv", sep=""), header=T, row.names=1))
    Truevalue <- exp(Truevalue)/(1+exp(Truevalue))
    
    NMvalue[,para]<-exp(NMvalue[,para])/(1+exp(NMvalue[,para]))
    
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".GBM.para.", para, ".csv", sep=""), header=T, row.names=1))
    GBMvalue <- exp(GBMvalue)/(1 + exp(GBMvalue))
    GBMvalue <- apply(GBMvalue, 2, mean)
    Para.GBM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(GBMvalue, Truevalue), rmse(GBMvalue, Truevalue))
    Para.NM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(NMvalue[, para], Truevalue, use="pairwise.complete.obs"), rmse(NMvalue[, para], Truevalue))
  }
}

apply(Para.GBM, 2, mean)
#Cor.kempt     Cor.kabs   Rmse.kempt    Rmse.kabs 
#0.9712358218 0.9865760517 0.0193308314 0.0005780817
apply(Para.NM, 2, mean)
#Cor.kempt   Cor.kabs Rmse.kempt  Rmse.kabs 
#0.94354180 0.42227912 0.02869651 0.02583557
boxplot(Para.GBM[, 1:2], ylim=c(-0.1, 1))
boxplot(Para.NM[, 1:2], ylim=c(-0.1, 1))

boxplot(Para.GBM[, 3:4], ylim=c(-0.1, 1))
boxplot(Para.NM[, 3:4], ylim=c(-0.1, 1))


#Association mapping
#markers that are in LD with QTLs are regared as true positives.
#The threshold of LD (r2) is Thr;
Thr <- 0.8
library(ROCR)
Genome.GBM <- matrix(NA, nr=length(Sim), nc=Np)
Genome.NM <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.GBM) <- Parametername
colnames(Genome.NM) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".QTL.", para, ".csv",sep=""), header=T, row.names=1))
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".GBM.genome.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".NM.genome.",para,".csv", sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(qtl in 1:5){
      Range <- (MajorQTL[qtl, 1] - 100):(MajorQTL[qtl, 1] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[qtl]] <- Which
    }
    
    ROCdata <- cbind(GBMvalue[, "Rho"], 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(GBMvalue[RegardedAsTrue[[qtl]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.GBM[sim, para] <- as.numeric(Auc.temp@y.values)
    
    ROCdata <- cbind(NMvalue, 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(NMvalue[RegardedAsTrue[[qtl]]])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.NM[sim, para] <- as.numeric(Auc.temp@y.values)
  }#para
}#sim


#associatin using BayesC after optimization with NM
Genome.NMBayesC <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.NMBayesC) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".QTL.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".NMBayesC.genome.", para, ".csv",sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(qtl in 1:5){
      Range <- (MajorQTL[qtl, 1] - 100):(MajorQTL[qtl, 1] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[qtl]] <- Which
    }
    
    ROCdata <- cbind(NMvalue[, "Rho"], 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(NMvalue[RegardedAsTrue[[qtl]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.NMBayesC[sim, para] <- as.numeric(Auc.temp@y.values)
  }#para
}#sim

apply(Genome.GBM, 2, mean)
#0.9973132 0.9978013 
apply(Genome.NM, 2, mean)
#0.9996973 0.8960901 
apply(Genome.NMBayesC, 2, mean)
#0.9967114 0.8746037 

boxplot(Genome.GBM, ylim=c(0, 1))
boxplot(Genome.NM, ylim=c(0, 1))
boxplot(Genome.NMBayesC, ylim=c(0, 1))


#One-half sampling points
#parameter estimates
Para.OneHalf.GBM <- matrix(NA, nr=length(Sim), nc=2 * Np)
Para.OneHalf.NM <- matrix(NA, nr=length(Sim), nc=2 * Np)
colnames(Para.OneHalf.GBM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
colnames(Para.OneHalf.NM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))

for(sim in Sim){
  NMvalue <- read.csv(paste("Sim", sim, ".OneHalf.NM.para.csv", sep=""), header=T, row.names=1)
  
  for(para in Parametername){
    Truevalue <- as.matrix(read.csv(paste("Sim", sim, ".", para, ".csv", sep=""), header=T, row.names=1))
    Truevalue <- exp(Truevalue)/(1+exp(Truevalue))
    
    NMvalue[,para]<-exp(NMvalue[,para])/(1+exp(NMvalue[,para]))
    
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneHalf.GBM.para.", para, ".csv", sep=""), header=T, row.names=1))
    GBMvalue <- exp(GBMvalue)/(1 + exp(GBMvalue))
    GBMvalue <- apply(GBMvalue, 2, mean)
    Para.OneHalf.GBM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(GBMvalue, Truevalue), rmse(GBMvalue, Truevalue))
    Para.OneHalf.NM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(NMvalue[, para], Truevalue, use="pairwise.complete.obs"), rmse(NMvalue[, para], Truevalue))
  }
}

apply(Para.OneHalf.GBM, 2, mean)
#Cor.kempt     Cor.kabs   Rmse.kempt    Rmse.kabs 
#0.9543495620 0.9738035336 0.0242838322 0.0008021089 
apply(Para.OneHalf.NM, 2, mean)
#Cor.kempt   Cor.kabs Rmse.kempt  Rmse.kabs 
#0.92099021 0.42580753 0.03448131 0.02745567 
boxplot(Para.OneHalf.GBM[, 1:2], ylim=c(-0.1, 1))
boxplot(Para.OneHalf.NM[, 1:2], ylim=c(-0.1, 1))


#Association mapping
Genome.OneHalf.GBM <- matrix(NA, nr=length(Sim), nc=Np)
Genome.OneHalf.NM <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.OneHalf.GBM) <- Parametername
colnames(Genome.OneHalf.NM) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".QTL.", para, ".csv",sep=""), header=T, row.names=1))
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneHalf.GBM.genome.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneHalf.NM.genome.",para,".csv", sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(qtl in 1:5){
      Range <- (MajorQTL[qtl, 1] - 100):(MajorQTL[qtl, 1] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[qtl]] <- Which
    }
    
    ROCdata <- cbind(GBMvalue[, "Rho"], 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(GBMvalue[RegardedAsTrue[[qtl]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.OneHalf.GBM[sim, para] <- as.numeric(Auc.temp@y.values)
    
    ROCdata <- cbind(NMvalue, 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(NMvalue[RegardedAsTrue[[qtl]]])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.OneHalf.NM[sim, para] <- as.numeric(Auc.temp@y.values)
  }#para
}#sim


#associatin using BayesC after optimization with NM
Genome.OneHalf.NMBayesC <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.OneHalf.NMBayesC) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".QTL.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneHalf.NMBayesC.genome.", para, ".csv",sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(qtl in 1:5){
      Range <- (MajorQTL[qtl, 1] - 100):(MajorQTL[qtl, 1] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[qtl]] <- Which
    }
    
    ROCdata <- cbind(NMvalue[, "Rho"], 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(NMvalue[RegardedAsTrue[[qtl]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.OneHalf.NMBayesC[sim, para] <- as.numeric(Auc.temp@y.values)
  }#para
}#sim

apply(Genome.OneHalf.GBM, 2, mean)
#0.9963130 0.9977472
apply(Genome.OneHalf.NM, 2, mean)
#0.9999027 0.8688072 
apply(Genome.OneHalf.NMBayesC, 2, mean)
#0.9963745 0.8466047


#One-fourth sampling points
#parameter estimates
Para.OneFourth.GBM <- matrix(NA, nr=length(Sim), nc=2 * Np)
Para.OneFourth.NM <- matrix(NA, nr=length(Sim), nc=2 * Np)
colnames(Para.OneFourth.GBM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
colnames(Para.OneFourth.NM) <- c(paste("Cor.", Parametername,sep=""), paste("Rmse.", Parametername,sep=""))
for(sim in Sim){
  NMvalue <- read.csv(paste("Sim", sim, ".OneFourth.NM.para.csv", sep=""), header=T, row.names=1)
  
  for(para in Parametername){
    Truevalue <- as.matrix(read.csv(paste("Sim", sim, ".", para, ".csv", sep=""), header=T, row.names=1))
    Truevalue <- exp(Truevalue)/(1+exp(Truevalue))
    
    NMvalue[,para]<-exp(NMvalue[,para])/(1+exp(NMvalue[,para]))
    
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneFourth.GBM.para.", para, ".csv", sep=""), header=T, row.names=1))
    GBMvalue <- exp(GBMvalue)/(1 + exp(GBMvalue))
    GBMvalue <- apply(GBMvalue, 2, mean)
    Para.OneFourth.GBM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(GBMvalue, Truevalue), rmse(GBMvalue, Truevalue))
    Para.OneFourth.NM[sim, c(paste("Cor", para, sep="."), paste("Rmse", para, sep="."))] <- c(cor(NMvalue[, para], Truevalue, use="pairwise.complete.obs"), rmse(NMvalue[, para], Truevalue))
  }
}

apply(Para.OneFourth.GBM, 2, mean)
#Cor.kempt    Cor.kabs  Rmse.kempt   Rmse.kabs 
#0.938055199 0.934235558 0.028349156 0.001260639
apply(Para.OneFourth.NM, 2, mean)
#Cor.kempt   Cor.kabs Rmse.kempt  Rmse.kabs 
#0.89052499 0.07541481 0.04294379 0.05739303 
boxplot(Para.OneFourth.GBM[, 1:3], ylim=c(-0.1, 1))
boxplot(Para.OneFourth.NM[, 1:3], ylim=c(-0.1, 1))


#Association mapping
Genome.OneFourth.GBM <- matrix(NA, nr=length(Sim), nc=Np)
Genome.OneFourth.NM <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.OneFourth.GBM) <- Parametername
colnames(Genome.OneFourth.NM) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".QTL.", para, ".csv",sep=""), header=T, row.names=1))
    GBMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneFourth.GBM.genome.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneFourth.NM.genome.",para,".csv", sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(qtl in 1:5){
      Range <- (MajorQTL[qtl, 1] - 100):(MajorQTL[qtl, 1] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[qtl]] <- Which
    }
    
    ROCdata <- cbind(GBMvalue[, "Rho"], 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(GBMvalue[RegardedAsTrue[[qtl]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.OneFourth.GBM[sim, para] <- as.numeric(Auc.temp@y.values)
    
    ROCdata <- cbind(NMvalue, 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(NMvalue[RegardedAsTrue[[qtl]]])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.OneFourth.NM[sim, para] <- as.numeric(Auc.temp@y.values)
    
  }#para
}#sim


#associatin using BayesC after optimization with NM
Genome.OneFourth.NMBayesC <- matrix(NA, nr=length(Sim), nc=Np)
colnames(Genome.OneFourth.NMBayesC) <- Parametername
for(sim in Sim){
  
  Geno <- as.matrix(read.csv(paste("Sim", sim, ".Genotype.csv", sep=""), header=T, row.names=1))
  
  for(para in Parametername){
    MajorQTL <- as.matrix(read.csv(paste("Sim", sim, ".QTL.", para, ".csv",sep=""), header=T, row.names=1))
    NMvalue <- as.matrix(read.csv(paste("Sim", sim, ".OneFourth.NMBayesC.genome.", para, ".csv",sep=""), header=T, row.names=1))
    
    RegardedAsTrue <- as.list(numeric(5))
    for(qtl in 1:5){
      Range <- (MajorQTL[qtl, 1] - 100):(MajorQTL[qtl, 1] + 100)
      Range <- Range[Range>0&Range<nrow(Geno)]
      LD <- cor(t(Geno[Range, ]))^2
      Which <- which(LD[101, ] > Thr)
      Which <- Which + Range[1] - 1
      RegardedAsTrue[[qtl]] <- Which
    }
    
    ROCdata <- cbind(NMvalue[, "Rho"], 0)
    for(qtl in 1:5){
      ROCdata[RegardedAsTrue[[qtl]][which.max(NMvalue[RegardedAsTrue[[qtl]], "Rho"])], 2] <- 1
    }
    ROCdata <- ROCdata[order(ROCdata[, 1], decreasing = TRUE), ]
    Pred <- prediction(ROCdata[, 1], ROCdata[, 2])
    Perf <- performance(Pred, "tpr", "fpr")
    Auc.temp <- performance(Pred, "auc")
    Genome.OneFourth.NMBayesC[sim, para] <- as.numeric(Auc.temp@y.values)

  }#para
}#sim

apply(Genome.OneFourth.GBM, 2, mean)
#0.9956642 0.9954231 
apply(Genome.OneFourth.NM, 2, mean)
#0.9995733 0.7315767
apply(Genome.OneFourth.NMBayesC, 2, mean)
#0.9920147 0.6948939 


#plot results#################################################################
tiff("Glucose_Para.tiff", unit="cm", width=12, height=12, res=400)
par(mfrow=c(1, 2))
par(mar=c(2.8, 2.6, 1.8, 0.5))
par(mgp=c(1.7, 0.6, 0))
Pos<-c(1.2, 2, 2.8)

#correlation (accuracy) of parameters
GBMvalue <- NULL
NMvalue <- NULL
GBMvalue <- cbind(apply(Para.GBM[,1:2], 2, mean), apply(Para.GBM[,1:2], 2, sd),
                  apply(Para.OneHalf.GBM[,1:2], 2, mean), apply(Para.OneHalf.GBM[,1:2], 2, sd),
                  apply(Para.OneFourth.GBM[,1:2],2, mean), apply(Para.OneFourth.GBM[,1:2], 2, sd))
NMvalue <- cbind(apply(Para.NM[,1:2],2,mean), apply(Para.NM[,1:2], 2, sd),
                 apply(Para.OneHalf.NM[,1:2],2,mean), apply(Para.OneHalf.NM[,1:2],2,sd),
                 apply(Para.OneFourth.NM[,1:2],2,mean) ,apply(Para.OneFourth.NM[,1:2],2,sd))

Slide <- 0.02
plot(Pos, GBMvalue[1, seq(1,6,2)], type="o", pch=1, col=1, lty=1, ylim=c(-0.1,1.1), xlim=c(1,3), xaxt="n",
     ylab="Correlation", xlab="# sampling points", main="Correlation")
axis(1, at=Pos, labels=c(20,10,5), las=2)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos, GBMvalue[1,seq(1,6,2)] + GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos, GBMvalue[1,seq(1,6,2)] - GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)

for(i in 2){
  points(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=1)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] + GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] - GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}

for(i in 1:2){
  points(Pos+(2+i-1)*Slide, NMvalue[i, seq(1,6,2)], type="o", pch=i, col=i, lty=2)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i, seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] + NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i, seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] - NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}
legend(1.4, 0.1, pch=1:2, col=1:2, legend=c("a","b"))


#mse (accuracy) of parameters
GBMvalue <- NULL
NMvalue <- NULL
GBMvalue <- cbind(apply(Para.GBM[,3:4],2,mean), apply(Para.GBM[,3:4],2,sd),
                  apply(Para.OneHalf.GBM[,3:4],2,mean), apply(Para.OneHalf.GBM[,3:4],2,sd),
                  apply(Para.OneFourth.GBM[,3:4],2,mean), apply(Para.OneFourth.GBM[,3:4],2,sd))
NMvalue <- cbind(apply(Para.NM[,3:4],2,mean), apply(Para.NM[,3:4],2,sd),
                 apply(Para.OneHalf.NM[,3:4],2,mean), apply(Para.OneHalf.NM[,3:4],2,sd),
                 apply(Para.OneFourth.NM[,3:4],2,mean), apply(Para.OneFourth.NM[,3:4],2,sd))

#scale
Scale <- apply(rbind(Para.GBM[,3:4], Para.OneHalf.GBM[,3:4], Para.OneFourth.GBM[,3:4],
                     Para.NM[,3:4], Para.OneHalf.NM[,3:4], Para.OneFourth.NM[,3:4]),
               2, max)
GBMvalue <- GBMvalue/Scale
NMvalue <- NMvalue/Scale

Slide <- 0.02
plot(Pos, GBMvalue[1,seq(1,6,2)], type="o", pch=1, col=1, lty=1, ylim=c(-0.1,1.0), xlim=c(1,3), xaxt="n", ylab="RMSE", xlab="# sampling points", main="MSE")
axis(1, at=Pos, labels=c(20,10,5), las=2)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos, GBMvalue[1,seq(1,6,2)] + GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos, GBMvalue[1,seq(1,6,2)] - GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)

for(i in 2){
  points(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=1)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] + GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] - GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}

for(i in 1:2){
  points(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=2)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] + NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] - NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}
legend(1.2, 1.0, lty=1:2, legend=c("JA","IA"))
dev.off()


#AUC
tiff("Glucose_Genome.tiff", unit="cm", width=12, height=12, res=400)
par(mfrow=c(1, 2))
par(mar=c(2.8, 2.6, 1.8, 0.5))
par(mgp=c(1.7, 0.6, 0))

#Whole genome regression
GBMvalue <- NULL
NMvalue <- NULL
GBMvalue <- cbind(apply(Genome.GBM,2,mean,na.rm=T), apply(Genome.GBM,2,sd,na.rm=T),
                  apply(Genome.OneHalf.GBM,2,mean,na.rm=T), apply(Genome.OneHalf.GBM,2,sd,na.rm=T),
                  apply(Genome.OneFourth.GBM,2,mean,na.rm=T), apply(Genome.OneFourth.GBM,2,sd,na.rm=T))
NMvalue <- cbind(apply(Genome.NMBayesC,2,mean,na.rm=T), apply(Genome.NMBayesC,2,sd,na.rm=T),
                 apply(Genome.OneHalf.NMBayesC,2,mean,na.rm=T), apply(Genome.OneHalf.NMBayesC,2,sd,na.rm=T),
                 apply(Genome.OneFourth.NMBayesC,2,mean,na.rm=T), apply(Genome.OneFourth.NMBayesC,2,sd,na.rm=T))

plot(Pos, GBMvalue[1,seq(1,6,2)], type="o", pch=1, col=1, lty=1, ylim=c(0.5,1.1), xlim=c(1,3), xaxt="n", ylab="AUC", xlab="# sampling points", main="JA vs. IA-W")
axis(1, at=Pos, labels=c(20,10,5), las=2)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos, GBMvalue[1,seq(1,6,2)] + GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos, GBMvalue[1,seq(1,6,2)] - GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)

for(i in 2){
  points(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=1)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] + GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] - GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}

for(i in 1:2){
  points(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=2)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] + NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] - NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}
legend(1.4, 0.8, pch=1:2, col=1:2, legend=c("a","b"))
legend(1, 0.60, lty=1:2, legend=c("JA","IA-W"))


#Single locus test
NMvalue <- cbind(apply(Genome.NM,2,mean,na.rm=T), apply(Genome.NM,2,sd,na.rm=T),
                 apply(Genome.OneHalf.NM,2,mean,na.rm=T), apply(Genome.OneHalf.NM,2,sd,na.rm=T),
                 apply(Genome.OneFourth.NM,2,mean,na.rm=T), apply(Genome.OneFourth.NM,2,sd,na.rm=T))

plot(Pos, GBMvalue[1,seq(1,6,2)], type="o", pch=1, col=1, lty=1, ylim=c(0.5,1.1), xlim=c(1,3), xaxt="n", ylab="AUC", xlab="# sampling points", main="JA vs. IA-S")
axis(1, at=Pos, labels=c(20,10,5), las=2)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos,GBMvalue[1,seq(1,6,2)] + GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)
arrows(Pos, GBMvalue[1,seq(1,6,2)], Pos,GBMvalue[1,seq(1,6,2)] - GBMvalue[1,seq(2,6,2)], angle=90, length=0.02, col=1)

for(i in 2){
  points(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=1)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] + GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)], Pos+(i-1)*Slide, GBMvalue[i,seq(1,6,2)] - GBMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}

for(i in 1:2){
  points(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], type="o", pch=i, col=i, lty=3)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] + NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
  arrows(Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)], Pos+(2+i-1)*Slide, NMvalue[i,seq(1,6,2)] - NMvalue[i,seq(2,6,2)], angle=90, length=0.02, col=i)
}
legend(1, 0.60, lty=c(1,3), legend=c("JA","IA-S"))
dev.off()
