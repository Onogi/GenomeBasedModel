#read input files#####################################################################
#Input files can be found at https://github.com/Onogi/HeadingDatePrediction
#Marker genotypes
Geno <- as.matrix(read.table("KKBIL_geno.txt"))
Geno <- t(Geno)
Nm <- nrow(Geno)
Nl <- ncol(Geno)

Geno[Geno==-9] <- NA
Af <- rowSums(Geno + 1, na.rm=T)
Af <- Af/(rowSums(!is.na(Geno)) * 2)
for(locus in 1:Nm){
  v <- Geno[locus, ]
  Geno[locus, is.na(v)] <- Af[locus] * 2 - 1
}

#Map information
Map <- t(read.table("KKBIL_geno_map.txt",header=F))
colnames(Map) <- c("Chr","Pos")
Map <- data.frame(Map)

#Phenotypes
Emergence <- as.matrix(read.table("BIL.emergencedate.txt"))
Heading <- as.matrix(read.table("BIL.headingdate.txt"))
Emergence[Emergence==-9] <- NA
Heading[Heading==-9] <- NA

#Environment information
Photo <- as.matrix(read.table("BIL.photoperiod.txt"))
Temp <- as.matrix(read.table("BIL.dailytemp.txt"))
Photo[Photo==-9] <- 0
Temp[Temp==-9] <- 0

#See Onogi et al. 2016 (https://link.springer.com/article/10.1007%2Fs00122-016-2667-5)
#for the details of the data.

#Emergence and Heading include the emergence dates and heading dates for each line (N=176) at each environment (N=9).
#Photo and Temp includes the photoperiods and temperatures at each environment
#Dates in Emergence and Heading correspond to row numbers in Photo and Temp.

#Markers nearest to heading date genes
Hdnearest <- c(59, 88, 92, 108, 112)#correspond to Hd6, Hd3a, Hd1, Hd2, and Hd5, respectively

Nl <- nrow(Emergence)
Ne <- ncol(Emergence)
Md <- nrow(Temp)


#create inputs of GenomeBasedModel###################################################
#see Onogi et al. 2016 (https://link.springer.com/article/10.1007%2Fs00122-016-2667-5) for the details of the model.

#observed days to heading (make all emergence days 1)
Y <- t(Heading - Emergence + 1)
Missing <- 999999
Y[is.na(Y)] <- Missing

#add temperature to input
Input <- NULL
x <- NULL
for(line in 1:Nl){
  v <- NULL
  for(env in 1:Ne){
    if(is.na(Emergence[line,env])){
      w <- Temp[1:nrow(Temp), env]#assume to be sowed at the first day when missing
    }else{
      w <- Temp[Emergence[line, env]:nrow(Temp), env]
    }
    if(length(w) < Md) w <- c(w, rep(0, Md - length(w)))
    v <- c(v, w)
  }
  x <- cbind(x, v)
}
Input <- rbind(Input, x)

#add photoperiod to input
x <- NULL
for(line in 1:Nl){
  v <- NULL
  for(env in 1:Ne){
    if(is.na(Emergence[line, env])){
      w <- Photo[1:nrow(Temp), env]#assume to be sowed at the first day when missing
    }else{
      w <- Photo[Emergence[line, env]:nrow(Temp), env]
    }
    if(length(w) < Md) w <- c(w, rep(0, Md - length(w)))
    v <- c(v, w)
  }
  x <- cbind(x, v)
}
Input <- rbind(Input, x)
rm(v, w, x)
Freevec <- c(Ne, Md)

Np <- 5#number of parameters
Referencevalues <- c(4, 1.61, 1.61, 10, 30)#from Onogi et al. (2016)


#add IDs in Y and Geno######################################################################
Y <- rbind(1:Nl, Y)
Geno <- rbind(1:Nl, Geno)


#Run GenomeBasedModel#######################################################################
Rcpp::sourceCpp('HeadingDateCalculation_InferPoTo.cpp')
library(GenomeBasedModel)
Methodcode <- c(2, 2, 2, 2, 2)#all EBL

Result1 <- GenomeBasedModel(Input, Freevec, Y, Missing, Np, Geno, Methodcode, Referencevalues, HeadingDateCalculation_cpp_InferPoTo,
                           Transformation = c(rep("log",3),"nt","nt"))

#Show the last two loops
#Loop 56 
#MPI
#Rhat: 0.9982861 
#Mean loglike: -2772.15 
#Residual var: 13.17628 
#Acceptance rate (parameters): 0.04836364 0.4136818 0.3181932 0.10325 0.1476818 
#Acceptance rate (residual var): 0.142 
#GWR para 1 residualvar (scaled): 0.15398  Nite: 64 
#GWR para 2 residualvar (scaled): 0.50697  Nite: 21 
#GWR para 3 residualvar (scaled): 0.01903  Nite: 54 
#GWR para 4 residualvar (scaled): 3.56445  Nite: 56 
#GWR para 5 residualvar (scaled): 0.68156  Nite: 51 

#Last loop
#MPI
#Mean loglike: -2765.004 
#Residual var: 12.79609 
#Acceptance rate (parameters): 0.04770833 0.4113939 0.3148674 0.101911 0.1455814 
#Acceptance rate (residual var): 0.1376667 
#GWR para 1 residualvar (scaled): 0.14271  Nite: 59 
#GWR para 2 residualvar (scaled): 0.50036  Nite: 34 
#GWR para 3 residualvar (scaled): 0.01858  Nite: 63 
#GWR para 4 residualvar (scaled): 7.13786  Nite: 55 
#GWR para 5 residualvar (scaled): 0.67179  Nite: 33 

#distributions of inferred parameters
Para.mean <- rbind(apply(exp(Result1$Para[[1]]), 2, mean),
                   apply(exp(Result1$Para[[2]]), 2, mean),
                   apply(exp(Result1$Para[[3]]), 2, mean),
                   apply(Result1$Para[[4]], 2, mean),
                   apply(Result1$Para[[5]], 2, mean))

hist(Para.mean[1,], breaks=seq(40,85,1), main="G", xlab="G")
hist(Para.mean[2,], breaks=seq(1.4,2.3,0.05), main="a", xlab="a")
hist(Para.mean[3,], breaks=seq(0.3,9,0.2), main="b", xlab="b")
hist(Para.mean[4,], breaks=seq(8.5,9,0.01), main="po", xlab="po")
hist(Para.mean[5,], breaks=seq(23,30,0.2), main="to", xlab="to")

cor(t(Para.mean))

rownames(Para.mean)<-c("G","a","b","Po","To")
colnames(Para.mean)<-1:176
write.csv(t(Para.mean),"Posteriormeans_20190731.csv")


#fitted values
Result1.fit <- matrix(NA, Ne, Nl)
v <- matrix(0, 300, Ne)
for(line in 1:Nl){
  for(s in 1:300){
    v [s,] <- HeadingDateCalculation_cpp_InferPoTo(Input[, line], 
                                                   Freevec, 
                                                   c(Result1$Para[[1]][s, line],
                                                     Result1$Para[[2]][s, line],
                                                     Result1$Para[[3]][s, line],
                                                     Result1$Para[[4]][s, line],
                                                     Result1$Para[[5]][s, line]))
  }
  Result1.fit[,line] <- apply(v, 2, mean)
}
for(i in 1:Ne){
  v <- as.vector(Y[i + 1,])
  v[v == Missing] <- NA
  plot(v, Result1.fit[i,], main = paste("Environment",i), xlab="Observed", ylab="Fitted")
  abline(0,1)
}
rm(v)

#SNP effects
plot(Result1$Genome[[1]]$Beta, main="SNP effects on logG", ylab="Effects on logG", xlab="SNPs")
plot(Result1$Genome[[2]]$Beta, main="SNP effects on loga", ylab="Effects on loga", xlab="SNPs")
plot(Result1$Genome[[3]]$Beta, main="SNP effects on logb", ylab="Effects on logb", xlab="SNPs")
plot(Result1$Genome[[4]]$Beta, main="SNP effects on Po", ylab="Effects on Po", xlab="SNPs")
plot(Result1$Genome[[5]]$Beta, main="SNP effects on To", ylab="Effects on To", xlab="SNPs")

temp<-cbind(Result1$Genome[[1]]$Beta,
            Result1$Genome[[2]]$Beta,
            Result1$Genome[[3]]$Beta,
            Result1$Genome[[4]]$Beta,
            Result1$Genome[[5]]$Beta)
colnames(temp)<-c("G","a","b","Po","To")
write.csv(temp,"Posteriormeans_SNPeffect.csv")
rm(temp)

#Relations between Hd1 genotypes and parameter b
which.max(Result1$Genome[[3]]$Beta)
92
table(Geno[92+1,])
#-1   0   1 
#45   3 128 

range(Para.mean[3,][Geno[92+1,]==-1])
#0.5164285 1.0780495
range(Para.mean[3,][Geno[92+1,]==0])
#1.490394 2.366810
range(Para.mean[3,][Geno[92+1,]==1])
#3.326030 8.100926


#use Nelder-Mead optimization################################################################################
#Objective functions
HeadingDateCalculation_optim <- function(parameters, input, freevec, y, missing){
  output <- HeadingDateCalculation_cpp_InferPoTo(input, freevec, parameters)
  use <- y != missing
  sum((y[use] - output[use])^2)
}
library(VIGoR)#used for genome-wide regression

#initial values are generated by fluctuating reference values
#SD for fluctuation is taken from true values
#Nini points are generated

Nini <- 100
Initialvalues <- NULL
for(i in 1:Nini){
  Initialvalues <- rbind(Initialvalues, Referencevalues + rnorm(Np, 0, Referencevalues * 0.1))
}

#optimize
Result.NM <- matrix(0, Nl, Np + 1)
for(i in 1:Nl){
  cat(i,"\n")
  temp <- matrix(0, Nini, Np + 1)
  for(j in 1:Nini){
    v <- optim(Initialvalues[j,], HeadingDateCalculation_optim, input = Input[,i], freevec = Freevec, y = Y[-1, i], missing = Missing, method = "Nelder-Mead")
    temp [j, 1] <- v$value
    temp [j, -1] <- v$par
  }
  Result.NM[i, ] <- temp[which.min(temp[, 1]), ]
}

hist(exp(Result.NM[,2]), breaks=seq(20,90,2), main="G", xlab="G")
hist(exp(Result.NM[,3]), breaks=seq(0.5,6,0.1), main="a", xlab="a")
hist(exp(Result.NM[,4]), breaks=seq(1,180,2), main="b", xlab="b")
hist(Result.NM[,5], breaks=seq(7,30,1), main="po", xlab="po")
hist(Result.NM[,6], breaks=seq(20,36,1), main="to", xlab="to")

#compare with GBM results
plot(Para.mean[1,], exp(Result.NM[,2]), main="G")
plot(Para.mean[2,], exp(Result.NM[,3]), main="a")
plot(Para.mean[3,], exp(Result.NM[,4]), main="b")
plot(Para.mean[4,], Result.NM[,5], main="po")
plot(Para.mean[5,], Result.NM[,6], main="to")

#Whole genome regression
Result.NM.fitting <- as.list(numeric(Np))
for(i in 1:Np){
  Y.sd <- as.vector(scale(Result.NM[, i+1]))
  temp <- vigor(Pheno=Y.sd, Geno=t(Geno[-1, ]), Method="EBL", Hyperparameters=matrix(c(0.1, 0.1, 1, 0.1),nr=1))
  Result.NM.fitting[[i]] <- cbind(temp$Beta, temp$Sd.beta)
}

plot(Result.NM.fitting[[1]][,1], main="SNP effects on logG", ylab="Effects on logG", xlab="SNPs")
plot(Result.NM.fitting[[2]][,1], main="SNP effects on loga", ylab="Effects on loga", xlab="SNPs")
plot(Result.NM.fitting[[3]][,1], main="SNP effects on logb", ylab="Effects on logb", xlab="SNPs")
plot(Result.NM.fitting[[4]][,1], main="SNP effects on Po", ylab="Effects on Po", xlab="SNPs")
plot(Result.NM.fitting[[5]][,1], main="SNP effects on To", ylab="Effects on To", xlab="SNPs")

#compare with GBM results
plot(Result1$Genome[[1]]$Beta, Result.NM.fitting[[1]][,1], main="SNP effects on logG")
plot(Result1$Genome[[2]]$Beta, Result.NM.fitting[[2]][,1], main="SNP effects on loga")
plot(Result1$Genome[[3]]$Beta, Result.NM.fitting[[3]][,1], main="SNP effects on logb")
plot(Result1$Genome[[4]]$Beta, Result.NM.fitting[[4]][,1], main="SNP effects on po")
plot(Result1$Genome[[5]]$Beta, Result.NM.fitting[[5]][,1], main="SNP effects on to")

#single marker test
Result.NM.fitting2 <- as.list(numeric(Np))
Nm <- nrow(Geno)-1
for(i in 1:Np){
  Result.NM.fitting2[[i]] <- numeric(Nm)
  Y.sd <- as.vector(scale(Result.NM[, i+1]))
  for(m in 1:Nm){
    temp <- lm(Y.sd ~ Geno[m+1,])
    Result.NM.fitting2[[i]][m] <- log10(summary(temp)[[4]][2,4])*(-1)
  }
}


#Leave one line out CV####################################################################################
rmse <- function(x, y){
  sqrt(mean((x-y)^2))
}

#GenomeBasedModel
Prediction <- matrix(0, nr=Ne, nc=Nl)
Target<-1:Nl
for(line in Target){
  Y.cv <- Y
  Y.cv[-1, line] <- Missing
  Result.cv <- GenomeBasedModel(Input, Freevec, Y.cv, Missing, Np, Geno,
                                Methodcode, Referencevalues, HeadingDateCalculation_cpp_InferPoTo,
                                Transformation = c(rep("log",3),"nt","nt"))
  
  Prediction[,line] <- HeadingDateCalculation_cpp_InferPoTo(Input[, line], 
                                                            Freevec, 
                                                            c(mean(Result.cv$Para[[1]][,line]),
                                                              mean(Result.cv$Para[[2]][,line]),
                                                              mean(Result.cv$Para[[3]][,line]),
                                                              mean(Result.cv$Para[[4]][,line]),
                                                              mean(Result.cv$Para[[5]][,line])))
}

#Accuracy at each environment
for(env in 1:Ne){
  Which <- Y[env+1,]!=Missing
  cat(env,
      cor(Y[env+1, Which], Prediction[env, Which]),
      rmse(Y[env+1, Which], Prediction[env, Which]),
      mean(abs(Y[env+1, Which] - Prediction[env, Which])),
      "\n")
  plot(Y[env+1, Which], Prediction[env, Which], main=env, xlab="obs", ylab="pred")
  abline(0,1)
}
#1 0.8230687 6.378675 4.903409 
#2 0.7533644 8.662955 6.426901 
#3 0.5997252 5.821581 4.166667 
#4 0.7236923 5.632308 3.939759 
#5 0.8260295 7.990762 5.965909 
#6 0.7468503 5.461165 3.932432 
#7 0.8132757 8.708016 6.545455 
#8 0.7482356 6.967457 5.727273 
#9 0.8187693 9.715264 7.340909 

#Overall accuracy
Which <- as.vector(Y[-1,])!=Missing
cor(as.vector(Y[-1,])[Which], as.vector(Prediction)[Which])
0.9361475
rmse(as.vector(Y[-1,])[Which], as.vector(Prediction)[Which])
7.445317
coef(lm(as.vector(Y[-1,])[Which] ~ as.vector(Prediction)[Which]))
1.031079 
mean(abs(as.vector(Y[-1,])[Which] - as.vector(Prediction)[Which]))
5.474334
plot(as.vector(Y[-1,])[Which], as.vector(Prediction)[Which]);abline(0,1)


#Nelder-Mead optimization
Prediction.NM<-matrix(0,nr=Ne,nc=Nl)
for(line in 1:Nl){
  PredictedPara <- numeric(Np)
  for(i in 1:Np){
    temp <- vigor(Pheno=Result.NM[-line, i+1], Geno=t(Geno[-1, -line]), Method="EBL", Hyperparameters=matrix(c(0.1, 0.1, 1, 0.1),nr=1), Printinfo = FALSE)
    PredictedPara[i] <- sum(temp$Beta*Geno[-1,line]) + temp$Alpha
  }
  
  Prediction.NM[,line] <- HeadingDateCalculation_cpp_InferPoTo(Input[,line], Freevec, PredictedPara)
}

#Accuracy at each environment
for(env in 1:Ne){
  Which <- Y[env+1,]!=Missing
  cat(env,
      cor(Y[env+1,Which], Prediction.NM[env,Which]),
      rmse(Y[env+1,Which], Prediction.NM[env,Which]),
      mean(abs(Y[env+1,Which] - Prediction.NM[env,Which])),
      "\n")
  plot(Y[env+1,Which], Prediction.NM[env,Which], main=env, xlab="obs", ylab="pred")
  abline(0,1)
}

#1 0.5646019 9.983509 7.75 
#2 0.5214267 11.71419 8.590643 
#3 0.5075359 7.538407 5.793103 
#4 0.5750349 7.589228 5.463855 
#5 0.5463149 13.10729 9.857955 
#6 0.6477659 7.212976 5.5 
#7 0.5013496 13.94245 10.5625 
#8 0.5778991 8.286078 6.261364 
#9 0.5263922 14.92881 11.67614 

Which <- as.vector(Y[-1,])!=Missing
cor(as.vector(Y[-1,])[Which], as.vector(Prediction.NM)[Which])
0.8684862
rmse(as.vector(Y[-1,])[Which], as.vector(Prediction.NM)[Which])
10.93174
coef(lm(as.vector(Y[-1,])[Which] ~ as.vector(Prediction.NM)[Which]))
0.9097302 
mean(abs(as.vector(Y[-1,])[Which] - as.vector(Prediction.NM)[Which]))
8.00065
plot(as.vector(Y[-1,])[Which], as.vector(Prediction.NM)[Which]);abline(0,1)


#plot the results###############################################################################
tiff("HeadingDate_LeaveOneLineOutCV.tiff", unit="cm", height=6, width=12, res=400)
par(mar=c(2.5, 2.5, 1, 0.5))
par(mgp=c(1.5, 0.6, 0))
par(mfrow=c(1, 2))
plot(as.vector(Y[-1,])[Which], as.vector(Prediction)[Which], ylim=c(50,170), xlim=c(50,170),
     xlab="Observed", ylab="Predicted", main="JA")
text(65, 160, round(cor(as.vector(Y[-1,])[Which], as.vector(Prediction)[Which]), 2))
abline(0,1)
plot(as.vector(Y[-1,])[Which], as.vector(Prediction.NM)[Which], ylim=c(50,170), xlim=c(50,170),
     xlab="Observed", ylab="Predicted", main="IA")
text(65, 160, round(cor(as.vector(Y[-1,])[Which], as.vector(Prediction.NM)[Which]), 2))
abline(0,1)
dev.off()

Col<-numeric(nrow(Map))
Col[(Map$Chr%%2)==1] <- 2
Col[(Map$Chr%%2)==0] <- 4


tiff("HeadingDate_ParametersAndSNPeffects.tiff", unit="cm", height=14, width=17.5, res=400)
par(mar=c(1.5, 1.5, 1, 0.2))
par(mgp=c(1.5, 0.6, 0))
par(mfrow=c(4, 5))
hist(Para.mean[1,], breaks=seq(20,90,2), main="G", xlab="", ylab="Frequency")
text(30, 35, "(A)", cex=1.5)
hist(Para.mean[2,], breaks=seq(0.5,6,0.2), main="Alpha", xlab="", ylab="")
hist(Para.mean[3,], breaks=seq(0.3,9,0.2), main="Beta", xlab="", ylab="")
hist(Para.mean[5,], breaks=seq(20,36,0.5), main="To", xlab="", ylab="")
hist(Para.mean[4,], breaks=seq(8.5,9,0.02), main="Po", xlab="", ylab="")

plot(abs(Result1$Genome[[1]]$Beta), main="", ylab="Effects", xlab="", col=Col)
text(25, 0.82, "(B)", cex=1.5)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[2]]$Beta), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[3]]$Beta),main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[5]]$Beta),main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[4]]$Beta),main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)

hist(exp(Result.NM[,2]), breaks=seq(20,90,2), main="", xlab="", ylab="Frequency")
text(30, 15, "(C)", cex=1.5)
hist(exp(Result.NM[,3]), breaks=seq(0.5,6,0.2), main="", xlab="", ylab="")
hist(exp(Result.NM[,4]), breaks=seq(1,180,3), main="", xlab="", ylab="")
hist(Result.NM[,6], breaks=seq(20,36,0.5), main="", xlab="", ylab="")
hist(Result.NM[,5], breaks=seq(7,30,0.5), main="", xlab="", ylab="")

plot(abs(Result.NM.fitting[[1]][,1]), main="", ylab="Effects", xlab="", col=Col)
text(25, 0.42, "(D)", cex=1.5)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[2]][,1]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[3]][,1]), main="",ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[5]][,1]), main="",ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[4]][,1]), main="",ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)

dev.off()

Mar1<-c(1.5, 3, 1, 0.2)
Mar2<-c(1.5, 1.5, 1, 0.2)
tiff("HeadingDate_ParametersAndSNPeffects2.tiff", unit="cm", height=17.5, width=17.5, res=400)
layout(matrix(c(rep(1,6), rep(2,5), rep(3,5), rep(4,5), rep(5,5),
                rep(6,6), rep(7,5), rep(8,5), rep(9,5), rep(10,5),
                rep(11,6), rep(12,5), rep(13,5), rep(14,5), rep(15,5),
                rep(16,6), rep(17,5), rep(18,5), rep(19,5), rep(20,5),
                rep(21,6), rep(22,5), rep(23,5), rep(24,5), rep(25,5)),
              nc=26,byrow=T))
par(mgp=c(1.5, 0.4, 0))
par(mar=Mar1)
hist(Para.mean[1,], breaks=seq(20,90,2), main="G", xlab="", ylab="Frequency")
text(30, 35, "(A)", cex=1.5)
par(mar=Mar2)
hist(Para.mean[2,], breaks=seq(0.5,6,0.2), main="Alpha", xlab="", ylab="")
hist(Para.mean[3,], breaks=seq(0.3,9,0.2), main="Beta", xlab="", ylab="")
hist(Para.mean[5,], breaks=seq(20,36,0.5), main="To", xlab="", ylab="")
hist(Para.mean[4,], breaks=seq(8.5,9,0.02), main="Po", xlab="", ylab="")

par(mar=Mar1)
plot(abs(Result1$Genome[[1]]$Beta), main="", ylab="Effects", xlab="", col=Col)
text(25, 0.82, "(B)", cex=1.5)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
par(mar=Mar2)
plot(abs(Result1$Genome[[2]]$Beta), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[3]]$Beta),main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[5]]$Beta),main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result1$Genome[[4]]$Beta),main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)

par(mar=Mar1)
hist(exp(Result.NM[,2]), breaks=seq(20,90,2), main="", xlab="", ylab="Frequency")
text(30, 15, "(C)", cex=1.5)
par(mar=Mar2)
hist(exp(Result.NM[,3]), breaks=seq(0.5,6,0.2), main="", xlab="", ylab="")
hist(exp(Result.NM[,4]), breaks=seq(1,180,3), main="", xlab="", ylab="")
hist(Result.NM[,6], breaks=seq(20,36,0.5), main="", xlab="", ylab="")
hist(Result.NM[,5], breaks=seq(7,30,0.5), main="", xlab="", ylab="")

par(mar=Mar1)
plot(abs(Result.NM.fitting[[1]][,1]), main="", ylab="Effects", xlab="", col=Col)
text(25, 0.42, "(D)", cex=1.5)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
par(mar=Mar2)
plot(abs(Result.NM.fitting[[2]][,1]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[3]][,1]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[5]][,1]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting[[4]][,1]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)

par(mar=Mar1)
plot(abs(Result.NM.fitting2[[1]]), main="", ylab="-log10P", xlab="", col=Col)
text(25, 8.5, "(E)", cex=1.5)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
par(mar=Mar2)
plot(abs(Result.NM.fitting2[[2]]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting2[[3]]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting2[[5]]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)
plot(abs(Result.NM.fitting2[[4]]), main="", ylab="", xlab="", col=Col)
for(i in 1:length(Hdnearest)) abline(v=Hdnearest[i], lty=2)

dev.off()

