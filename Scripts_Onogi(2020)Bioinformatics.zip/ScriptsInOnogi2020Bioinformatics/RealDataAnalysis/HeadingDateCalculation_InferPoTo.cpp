#include <Rcpp.h>
using namespace Rcpp;
//Calculate rice heading dates using the DVR model of Yin et al. (1997) and Nakagawa et al. (2005).

//[[Rcpp::export]]
NumericVector HeadingDateCalculation_cpp_InferPoTo(NumericVector input, NumericVector freevec, NumericVector parameter)
{
  double cumdvs, dvs, dvs1, dvs2;
  double g, a, b;
  double pb=0.0, pc=24.0, po, popb, pcpo, pratio, pd, gpd;
  double tb=8.0, tc=42.0, to, totb, tcto, tratio, td, ftd;
  int env, day, envmd;
  int ne, md, nemd;
  int photosensitive;
  
  g = exp(parameter(0));
  a = exp(parameter(1));
  b = exp(parameter(2));
  po = parameter(3);
  to = parameter(4);
  popb = po - pb;
  pcpo = pc - po;
  pratio = pcpo / popb;
  totb = to - tb;
  tcto = tc - to;
  tratio = tcto / totb;
  dvs1 = 0.145*g + 0.005*g*g;
  dvs2 = 0.345*g + 0.005*g*g;
  
  ne = (int)freevec(0);
  md = (int)freevec(1);
  nemd = ne * md;
  NumericVector output(ne);
  
  for (env = 0; env<ne; ++env)
  {
    envmd = env * md;
    
    for (day = 0, cumdvs = 0.0, photosensitive = 0; day < md; ++day)/* include the emergence day*/
    {
      if (photosensitive)
      {
        pd = input(nemd + envmd + day);
        if(pd<po) gpd = 1.0; else gpd = (pd - pb)/popb * pow((pc - pd)/pcpo, pratio);
        
        td = input(envmd + day);
        if(td<tb||td>tc) ftd = 0.0; else ftd = (td - tb)/totb * pow((tc - td)/tcto, tratio);
        dvs = pow(ftd, a)*pow(gpd, b);
      }
      else
      {
        td = input(envmd + day);
        if(td<tb||td>tc) ftd = 0.0; else ftd = (td - tb)/totb * pow((tc - td)/tcto, tratio);
        dvs = pow(ftd, a);
      }
      
      if ((cumdvs + dvs) >= dvs1 && (cumdvs + dvs) <= dvs2)
      {
        pd = input(nemd + envmd + day);
        if(pd<po) gpd = 1.0; else gpd = (pd - pb)/popb * pow((pc - pd)/pcpo, pratio);

        td = input(envmd + day);
        if(td<tb||td>tc) ftd = 0.0; else ftd = (td - tb)/totb * pow((tc - td)/tcto, tratio);        
        dvs = pow(ftd, a)*pow(gpd, b);
        photosensitive = 1;
      }
      else
      {
        td = input(envmd + day);
        if(td<tb||td>tc) ftd = 0.0; else ftd = (td - tb)/totb * pow((tc - td)/tcto, tratio);
        dvs = pow(ftd, a);
        photosensitive = 0;
      }
      cumdvs += dvs;
      if(cumdvs > g) break;
    }
    output(env) = day + 1;
  }
  return output;
}
