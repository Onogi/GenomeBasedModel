#Simulate GIGANTEA expression accroding to Nagano et al. 2012########################################
#Use the genotype of RILs used in Onogi A et al. 2016
#KKBIL_geno.txt can be found at https://github.com/Onogi/HeadingDatePrediction
Geno <- as.matrix(read.table("KKBIL_geno.txt"))
Geno <- t(Geno)
Nm <- nrow(Geno)
Nl <- ncol(Geno)

Geno[Geno==-9] <- NA
Af <- rowSums(Geno + 1, na.rm=T)
Af <- Af/(rowSums(!is.na(Geno)) * 2)
for(locus in 1:Nm){
  v <- Geno[locus, ]
  Geno[locus, is.na(v)] <- Af[locus] * 2 - 1
}
range(Geno)
#[1] -1  1
write.csv(Geno, "Geno.csv")


#let a, b, th, and ol be the genotype specific parameters
Allpara<-c("a", "b", "pl", "th", "os", "ol")
Gpara<-c("a", "b", "th", "ol")
Cpara<-c("pl", "os")#the others are the common parameters

#values from Nagano et al. (2012)
#a and b were modified because we did not scale E.
Referencevalue <- c(12.8, -8.47/1000, 371, 14.78, 21.2 * 60, 7.73 * 60, 0.506)
names(Referencevalue) <- c("a", "b", "pl", "th", "os", "ol", "sigma")

#use temperatures of 4th - 7th June 2008 at Tsukuba, Japan
Temp.min <- read.csv("Tsukuba2008temperature.min.csv", header=T, row.names=1)
Start <- which(Temp.min$Month==6&Temp.min$Day==4&Temp.min$Hour==1&Temp.min$Min==1)
End <- which(Temp.min$Month==6&Temp.min$Day==8&Temp.min$Hour==1&Temp.min$Min==0)
Temp.min.copy <- Temp.min[Start:End, ]
Temp <- Temp.min$Temp[Start:End]

#sample every 2 hours from 6/5 10:01 to 6/7 10:01
Samplingpoint<-which((Temp.min.copy$Month==6&Temp.min.copy$Day==5&is.element(Temp.min.copy$Hour,seq(10,24,2))&Temp.min.copy$Min==1)|
              (Temp.min.copy$Month==6&Temp.min.copy$Day==6&is.element(Temp.min.copy$Hour,seq(2,24,2))&Temp.min.copy$Min==0)|
              (Temp.min.copy$Month==6&Temp.min.copy$Day==7&is.element(Temp.min.copy$Hour,seq(2,10,2))&Temp.min.copy$Min==1)
)
Temp.min.copy[Samplingpoint, ]
write.csv(Temp.min.copy, "Temperature.csv")
write.csv(Samplingpoint, "Samplingpoint.csv")


#see sensitivity of parameters
GIGANTEA<-function(tvec, a, b, pl, th, os, ol, Tmp){
  
  #tvec and Tmp are vectors
  #Tmp starts from 01:01 of the day before the first day and ends at 01:00 of the day after the last day.
  #The index represents 1 min.
  
  L <- length(Temp)
  os.row <- os-61#Because Tmp starts from 01:01
  Os <- seq(os.row, L, 1440)
  Ol <- round(ol)
  OsOl <- NULL
  for(i in 1:length(Os)){
    OsOl <- c(OsOl, Os[i]:(Os[i]+Ol))
  }
  OsOl <- OsOl[-which(OsOl>L)]
  Exclude <- rep(TRUE, L)
  Exclude[OsOl] <- FALSE
  pl <- round(pl)
  
  Output <- numeric(length(tvec))
  for(i in 1:length(tvec)){
    t <- tvec[i]
    trange <- (t-pl):t
    exclude <- Exclude[trange]
    f <- Tmp[trange]-th
    f[exclude] <- 0
    E <- sum(f)
    Output[i] <- E
  }
  Output <- a + Output*b
  Output
}

Nrandom <- 200
Sd <- seq(0.02, 0.2, 0.02)
for(para in Allpara){
  cat("#", para, "\n")
  for(s in Sd){
    value <- matrix(rep(Referencevalue[1:6], each=Nrandom), nc=6)
    colnames(value) <- Allpara
    value[, para] <- value[, para] + rnorm(Nrandom, 0, abs(value[1, para]) * s)
    Sample <- NULL
    for(r in 1:Nrandom){
      Sample <- rbind(Sample, GIGANTEA(Samplingpoint, value[r,"a"], value[r,"b"], value[r,"pl"], value[r,"th"], value[r,"os"], value[r,"ol"], Temp))
    }
    cat("#", s, sum(apply(Sample, 2, var)),"\n")
  }
}
# a 
# 0.02 1.697601 
# 0.04 6.321048 
# 0.06 14.42613 
# 0.08 26.49415 
# 0.1 44.42542 
# 0.12 60.65895 
# 0.14 74.68686 
# 0.16 116.5958 
# 0.18 137.8526 
# 0.2 124.4317 
# b 
# 0.02 0.3124502 
# 0.04 1.144997 
# 0.06 2.332481 
# 0.08 4.537633 
# 0.1 10.47679 
# 0.12 9.946111 
# 0.14 15.51428 
# 0.16 20.13355 
# 0.18 27.59506 
# 0.2 32.36689 
# pl 
# 0.02 0.370038 
# 0.04 1.602295 
# 0.06 3.884239 
# 0.08 6.938709 
# 0.1 10.9443 
# 0.12 14.39839 
# 0.14 18.94684 
# 0.16 26.20571 
# 0.18 31.96215 
# 0.2 36.09391 
# th 
# 0.02 4.548101 
# 0.04 21.64602 
# 0.06 37.96639 
# 0.08 70.733 
# 0.1 126.5327 
# 0.12 170.4448 
# 0.14 268.5104 
# 0.16 304.6466 
# 0.18 375.0573 
# 0.2 495.9882 
# os 
# 0.02 7.936039 
# 0.04 35.21142 
# 0.06 65.05322 
# 0.08 128.4191 
# 0.1 153.8166 
# 0.12 210.8404 
# 0.14 240.5223 
# 0.16 262.2871 
# 0.18 269.1288 
# 0.2 285.0706 
# ol 
# 0.02 0.351868 
# 0.04 1.481225 
# 0.06 2.766296 
# 0.08 5.115979 
# 0.1 8.636172 
# 0.12 13.13063 
# 0.14 16.654 
# 0.16 25.09297 
# 0.18 35.46889 
# 0.2 45.6618 

#determine sd values used
Usesd<-c(0.08, 0.18, 0.16, 0.06, 0.04, 0.16)
Var <- (Referencevalue[Allpara] * Usesd)^2
Var
#1.048576e+00 2.324405e-06 3.523610e+03 7.864142e-01 2.588774e+03 5.506827e+03 

h2 <- 0.8#heritability of parameters
Ngp <- length(Gpara)
Ncp <- length(Cpara)
Nqtl <- 5

Nsim <- 100
for(sim in 1:Nsim){

  QTL <- as.list(numeric(Ngp))
  names(QTL) <- Gpara
  for(para in Gpara){
    QTL[[para]] <- cbind(sort(sample(1:Nm, Nqtl, replace=F)), rnorm(Nqtl, 0, sqrt(Var[para]/5)))
  }
  for(para in Gpara){
    write.csv(QTL[[para]], paste("Sim", sim, ".QTL.", para, ".csv", sep=""))
  }
  
  #create genotype specific parameters
  BV <- matrix(0, nr=Nl, nc=Ngp)
  colnames(BV) <- Gpara
  for(para in Gpara){
    BV[, para] <- t(Geno[QTL[[para]][, 1], ])%*%QTL[[para]][, 2, drop=F] + Referencevalue[para]
  }
  
  #add random noises
  Paravalue <- matrix(0, nr=Nl, nc=Ngp + Ncp)
  colnames(Paravalue) <- Allpara
  for(para in Gpara){
    v <- var(BV[, para])
    Paravalue[, para] <- BV[, para] + rnorm(Nl, 0, sqrt((1 - h2)/h2 * v))
  }
  Paravalue[, "pl"] <- Referencevalue["pl"]
  Paravalue[, "os"] <- Referencevalue["os"]
  
  Y <- matrix(NA, nr=Nl, nc=length(Samplingpoint))
  for(line in 1:Nl){
    Y[line, ] <- GIGANTEA(Samplingpoint,
                          Paravalue[line,"a"],
                          Paravalue[line,"b"],
                          Paravalue[line,"pl"],
                          Paravalue[line,"th"],
                          Paravalue[line,"os"],
                          Paravalue[line,"ol"],
                          Temp) + rnorm(length(Samplingpoint), 0, Referencevalue["sigma"])
  }
  
  write.csv(t(Y), paste("Sim", sim, ".Y.csv", sep=""))
  write.csv(t(BV), paste("Sim", sim, ".Genotypicvalue.csv", sep=""))
  write.csv(t(Paravalue), paste("Sim", sim, ".Parameters.csv", sep=""))
}


#Simulate missing values in Y
Missingprop <- seq(0.1, 0.9, 0.1)

#select observations to be missed
for(sim in 1:Nsim){
  
  Remove <- as.list(numeric(length(Missingprop)))
  names(Remove) <- Missingprop
  for(prop in Missingprop){
    Remove[[as.character(prop)]] <- matrix(FALSE, 25, Nl)
    Nremove <- round(Nl * prop)
    for(i in 1:25){
      Remove[[as.character(prop)]][i, sample(1:Nl, Nremove, replace=F)] <- TRUE
    }
    write.csv(Remove[[as.character(prop)]], paste("Sim",sim,".missing.",prop*10,".csv",sep=""))
  }
}

