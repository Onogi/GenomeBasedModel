Filsed included:

RunGenomeBasedModel.R
An R script to run GenomeBasedModel

RunGenomeBasedModel.RData
Results of RunGenomeBasedModel.R

HeadingDateCalculation.R
An R script describing the DVR model

HeadingDateCalculation.cpp
An C++ script describing the DVR model

Geno.csv, EmergenceDate.csv, HeadingDate.csv, Photoperiod.csv, Temperature.csv
These files are used in Onogi et al. (2016) Theor. Appl. Genet. 129, 805-817.
Please cite the paper if use these files for other purposes.
