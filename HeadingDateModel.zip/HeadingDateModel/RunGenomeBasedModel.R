#Build the genome-based model on HeadingDateCalculation.cpp/HeadingDateCalculation.R
#by Akio Onogi, June 2018.

#read input files#####################################################################
#see Onogi et al. 2016 (https://link.springer.com/article/10.1007%2Fs00122-016-2667-5)
#for the details of the data.
#Please cite the paper when using these files for other purposes.
Emergence <- as.matrix(read.csv("EmergenceDate.csv", header=T, row.names=1))
Heading <- as.matrix(read.csv("HeadingDate.csv", header=T, row.names=1))
Photo <- as.matrix(read.csv("Photoperiod.csv", header=T, row.names=1))
Temp <- as.matrix(read.csv("Temperature.csv", header=T, row.names=1))
Geno <- as.matrix(read.csv("Geno.csv", header=T, row.names=1))

#Emergence and Heading include the emergence dates and heading dates
#for each individual (N=176) at each environment(N=9).
#Photo and Temp includes the photoperiods and temperatures at each environment
#Dates in Emergence and Heading correspond to row numbers in Photo and Temp.

Nl <- nrow(Emergence)
Ne <- ncol(Emergence)
Md <- nrow(Temp)


#create inputs of GenomeBasedModel###################################################
#see Onogi et al. 2016 (https://link.springer.com/article/10.1007%2Fs00122-016-2667-5)
#for the details of the model.
Tb <- 8
To <- 30
Tc <- 42
Pb <- 0
Po <- 10
Pc <- 24

ToTb <- To-Tb
TcTo <- Tc-To
Tratio <- TcTo/ToTb
PoPb <- Po-Pb
PcPo <- Pc-Po
Pratio <- PcPo/PoPb

#observed days to heading (make all emergence days 1)
Y <- t(Heading - Emergence + 1)
Missing <- 999999
Y[is.na(Y)] <- Missing

#add temperature to input after conversion
Input <- NULL
x <- NULL
for(line in 1:Nl){
  v <- NULL
  for(env in 1:Ne){
    if(is.na(Emergence[line,env])){
      w <- Temp[1:nrow(Temp), env]#assume to be sowed at the first day when missing
    }else{
      w <- Temp[Emergence[line, env]:nrow(Temp), env]
      if(length(w) < Md) w <- c(w, rep(0, Md - length(w)))
      w[w < Tb & !is.na(w)] <- 0
      w[w > Tc & !is.na(w)] <- 0
      w[w >= Tb & w <= Tc & !is.na(w)] <- (w[w >= Tb & w <= Tc & !is.na(w)] - Tb)/ToTb * ((Tc - w[w >= Tb & w <= Tc & !is.na(w)])/TcTo)^Tratio
    }
    v <- c(v, w)
  }
  x <- cbind(x, v)
}
Input <- rbind(Input, x)

#add photoperiod to input after conversion
x <- NULL
for(line in 1:Nl){
  v <- NULL
  for(env in 1:Ne){
    if(is.na(Emergence[line, env])){
      w <- Photo[1:nrow(Temp), env]#assume to be sowed at the first day when missing
    }else{
      w <- Photo[Emergence[line, env]:nrow(Temp), env]
      if(length(w) < Md) w <- c(w, rep(0, Md - length(w)))
      w[w<Po & !is.na(w)]<-1
      w[w >=Po & !is.na(w)]<-(w[w >= Po & !is.na(w)] - Pb)/PoPb * ((Pc - w[ w>=Po & !is.na(w)])/PcPo)^Pratio
    }
    v <- c(v, w)
  }
  x <- cbind(x, v)
}

Input <- rbind(Input, x)
Freevec <- c(Ne, Md)
rm(v, w, x)

Np <- 3#number of parameters in HeadingDateCalculation
Referencevalues <- c(4, 1.61, 1.61)#from Onogi et al. (2016)


#add IDs in Y and Geno######################################################################
Y <- rbind(1:Nl, Y)
Geno <- rbind(1:Nl, Geno)


#Run GenomeBasedModel#######################################################################
Rcpp::sourceCpp('HeadingDateCalculation.cpp')
source("HeadingDateCalculation.R")
library(GenomeBasedModel)
Methodcode <- c(8, 4, 2)#GBLUP, BayesC, and EBL are applied.
#But note that, because model parameters are not polygenic in this data,
#variable selection methods (BayesB, BayesB, and EBL) are more suitable for all the parameters

#This will take 30 to 50 min.
Result.Cpp <- GenomeBasedModel(Input, Freevec, Y, Missing, Np, Geno, Methodcode, Referencevalues, HeadingDateCalculation_cpp,
                               Transformation = rep("log", Np))


#distributions of inferred parameters
Para.mean <- rbind(apply(Result.Cpp$Para[[1]], 2, mean),
                   apply(Result.Cpp$Para[[2]], 2, mean),
                   apply(Result.Cpp$Para[[3]], 2, mean))

hist(Para.mean[1,])
hist(Para.mean[2,])
hist(Para.mean[3,])


#fitted values
Result.Cpp.fit <- matrix(NA, Ne, Nl)
v <- matrix(0, 300, Ne)
for(line in 1:Nl){
  for(s in 1:300){
    v [s,] <- HeadingDateCalculation_cpp(Input[, line], Freevec, c(Result.Cpp$Para[[1]][s, line],
                                                                   Result.Cpp$Para[[2]][s, line],
                                                                   Result.Cpp$Para[[3]][s, line]))
  }
  Result.Cpp.fit[,line] <- apply(v, 2, mean)
}
for(i in 1:Ne){
  v <- as.vector(Y[i + 1,])
  v[v == Missing] <- NA
  plot(v, Result.Cpp.fit[i,], main = paste("Environment",i), xlab="Observed", ylab="Fitted")
  abline(0,1)
}
rm(v)

#Breeding value (genotypic value) (GBLUP)
plot(Result.Cpp$Genome[[1]]$U)

#SNP effects (EBV and BayesC)
plot(Result.Cpp$Genome[[2]]$Beta)
plot(Result.Cpp$Genome[[3]]$Beta)

#Inclusion probability of SNPs (BayesC)
plot(Result.Cpp$Genome[[2]]$Rho)


#Use HeadingDateCalculation_R. Slower than Cpp so readers may want to kill the job.
Result.R <- GenomeBasedModel(Input, Freevec, Y, Missing, Np, Geno, Methodcode, Referencevalues, HeadingDateCalculation_R,
                             Transformation = rep("log", Np))

#Breeding value (genotypic value) (GBLUP)
plot(Result.R$Genome[[1]]$U)

#SNP effects (EBV and BayesC)
plot(Result.R$Genome[[2]]$Beta)
plot(Result.R$Genome[[3]]$Beta)

#Inclusion probability of SNPs (BayesC)
plot(Result.R$Genome[[2]]$Rho)

#compare with the cpp results
plot(Result.Cpp$Genome[[1]]$U, Result.R$Genome[[1]]$U)
plot(Result.Cpp$Genome[[2]]$Beta, Result.R$Genome[[2]]$Beta)
plot(Result.Cpp$Genome[[3]]$Beta, Result.R$Genome[[3]]$Beta)


