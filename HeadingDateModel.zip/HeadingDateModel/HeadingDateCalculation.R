HeadingDateCalculation_R<-function(input, freevec, parameter){

  g <- exp(parameter[1])
  a <- exp(parameter[2])
  b <- exp(parameter[3])
  dvs1 <- 0.145*g + 0.005*g*g
  dvs2 <- 0.345*g + 0.005*g*g
  
  ne <- freevec[1]
  md <- freevec[2]
  nemd = ne * md
  output <- numeric(ne)
  
  for (env in 1:ne){
    
    envmd <- (env - 1) * md
    headingdate <- input[env]
    seq.a <- input[(envmd + 1):(envmd + md)]^a
    seq.b <- input[(nemd + envmd + 1):(nemd + envmd + md)]^b
    dvs <- input[(envmd + 1):(envmd + md)]^a
    #print(dvs)
    
    cumdvs <- cumsum(dvs)
    Pos <- (cumdvs >= dvs1)
    #print(which(Pos))
    #if (sum(Pos) > 0){
    if (sum(Pos) > 1){
      Pos2 <- which(Pos)[-1]
      dvs [Pos2] <- seq.a [Pos2] * seq.b [Pos2]
      cumdvs <- cumsum(dvs)
      Pos <- (cumdvs > dvs2)
      #print(which(Pos))
      #if (sum(Pos) > 0){
      if (sum(Pos) > 1){
        Pos2 <- which(Pos)[-1]
        dvs [Pos2] <- seq.a [Pos2]
        cumdvs <- cumsum(dvs)
      }
    }
    v <- which(cumdvs>g)
    if(length(v)>0){
      output[env] <- min(v)
    }else{
      output[env] <- md + 1
    }
  }
  output
}
