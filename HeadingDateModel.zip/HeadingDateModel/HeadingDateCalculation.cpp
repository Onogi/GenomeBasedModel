#include <Rcpp.h>
using namespace Rcpp;
/*
 Calculate heading dates according to the DVR model.
 */
//[[Rcpp::export]]
NumericVector HeadingDateCalculation_cpp(NumericVector input, NumericVector freevec, NumericVector parameter)
{
  double dvs, dvs1, dvs2;
  double g, a, b;
  int env, day, envmd;
  int ne, md, nemd;

  g = exp(parameter(0));
  a = exp(parameter(1));
  b = exp(parameter(2));
  dvs1 = 0.145*g + 0.005*g*g;
  dvs2 = 0.345*g + 0.005*g*g;
  
  ne = (int)freevec(0);
  md = (int)freevec(1);
  nemd = ne * md;
  NumericVector output(ne);
  
  for (env = 0; env<ne; ++env)
  {
    envmd = env * md;
    
    for (day = 0, dvs = 0.0; day < md; ++day)// include the emergence day
    {
      if (dvs >= dvs1 && dvs <= dvs2)
      {
        dvs += pow(input(envmd + day), a)*pow(input(nemd + envmd + day), b);
      }
      else
      {
        dvs += pow(input(envmd + day), a);
      }
      if(dvs > g) break;
    }
    output(env) = day + 1;
  }
  return output;
}
