ModelParameterInference_R <- function(Input, Freevec, Y, Missing,
                                    Nl, Ne, Np, Nr,
                                    SampledPara, SampledVe,
                                    MeanOfPrior, VarOfPrior, Ve, Nve, Residualgroup,
                                    SdforParameters, SdforVe, Loglike,
                                    Burnin, Thi, Totalite, Order,
                                    Lowerlimit, Upperlimit, AccParameters, AccVe, Model,
                                    NeNl, Nmiss, Missingposition, Imputemissing, Transformation){

  #Caluculate the exponential of likelihood for line i.
  Loglikelihood<-function(output, y, ve, ne, missing, nve, residualgroup){

    loglikelihood = 0
    loglikelihoodvec = rep(0, nve)
    dev <- (-1) * (y - output)^2

    for (env in 1:ne)
    {
      if(y[env]!=missing)
        loglikelihoodvec[residualgroup[env]] <- loglikelihoodvec[residualgroup[env]] + dev[env]
    }
    loglikelihoodvec <- loglikelihoodvec * 0.5/ve
    loglikelihood <- sum(loglikelihoodvec)

    return(list(loglikelihood,loglikelihoodvec))
  }

  Loglikelihood_nomissing <- function(output, y, ve, ne, nve, residualgroup){

    loglikelihood = 0
    loglikelihoodvec = rep(0, nve)
    dev <- (-1) * (y - output)^2

    for (env in 1:ne)
    {
      loglikelihoodvec[residualgroup[env]] <- loglikelihoodvec[residualgroup[env]] + dev[env]
    }
    loglikelihoodvec <- loglikelihoodvec * 0.5/ve
    loglikelihood <- sum(loglikelihoodvec)

    return(list(loglikelihood,loglikelihoodvec))
  }

  #log density of normal distribution
  LogDensityNormalKernel <- function(v, mu, var){
    return(-0.5 * ((v - mu)^2.0) / var)
  }

  #Output of the model
  Output_current <- matrix(0, nrow=Ne, ncol=Nl)
  Output_proposed <- matrix(0, nrow=Ne, ncol=Nl)

  #Likelihood vector
  ProposedloglikeVec <- rep(0, Nve)
  CurrentloglikeVec <- rep(0, Nve)

  #Initialization
  Parameters <- matrix(rnorm(Np * Nl, as.vector(MeanOfPrior), as.vector(sqrt(VarOfPrior))), nrow=Np)
  for (para in 1:Np){
    Parameters[para, Parameters[para, ]<=Lowerlimit[para]] <- Lowerlimit[para] + 1e-5
    Parameters[para, Parameters[para, ]>=Upperlimit[para]] <- Upperlimit[para] - 1e-5
  }
  for (line in 1:Nl){
    Output_current[,line] <- Model(Input[,line], Freevec, Parameters[,line])
  }
  if (Imputemissing){
    for (line in 1:Nmiss)
    {
      Y[Missingposition[line,1],Missingposition[line,2]] <-
        rnorm(1, Output_current[Missingposition[line,1],Missingposition[line,2]], sqrt(Ve[Residualgroup[Missingposition[line,1]]]));
    }
  }
  CumNs <- 0;
  CumNsab <- 0;
  Nsab <- (Totalite - Burnin) / Thi;

  for (mcmc in 1:Totalite){

    #Sample or Not
    if (mcmc %% Thi == 0){
      DoSampling <- 1; CumNs <- CumNs + 1
    }else{
      DoSampling <- 0
    }
    if (DoSampling&mcmc>Burnin) {
      AfterBurnin <- 1; CumNsab <- CumNsab + 1
    }else{
      AfterBurnin <- 0;
    }

    #Update of model parameters
    for (para in 1:Np){

      Veloglikelihood <- rep(0, Nve)

      for (line in 1:Nl){

        target <- Order[line]

        Sd <- SdforParameters[para]
        Mu <- MeanOfPrior[para, target]
        Sigma <- VarOfPrior[para]
        currentpara <- Parameters[,target]
        proposedpara <- Parameters[,target]

        MHprob <- 0.0;
        proposedpara[para] <- rnorm(1, currentpara[para], Sd)

        if(proposedpara[para]>Lowerlimit[para]&proposedpara[para]<Upperlimit[para]){
          Output_proposed[,target] = Model(Input[,target], Freevec, proposedpara)
          if(Imputemissing)
          {
            Temp <- Loglikelihood_nomissing(Output_current[,target], Y[,target], Ve, Ne, Nve, Residualgroup)
            Currentloglike <- Temp[[1]]
            CurrentloglikeVec <- Temp[[2]]
            Temp <- Loglikelihood_nomissing(Output_proposed[,target], Y[,target], Ve, Ne, Nve, Residualgroup)
            Proposedloglike <- Temp[[1]]
            ProposedloglikeVec <- Temp[[2]]
          }
          else
          {
            Temp <- Loglikelihood(Output_current[,target], Y[,target], Ve, Ne, Missing, Nve, Residualgroup)
            Currentloglike <- Temp[[1]]
            CurrentloglikeVec <- Temp[[2]]
            Temp <- Loglikelihood(Output_proposed[,target], Y[,target], Ve, Ne, Missing, Nve, Residualgroup)
            Proposedloglike <- Temp[[1]]
            ProposedloglikeVec <- Temp[[2]]
          }
          MHprob <- MHprob + Proposedloglike
          MHprob <- MHprob - Currentloglike

          MHprob <- MHprob + LogDensityNormalKernel(proposedpara[para], Mu, Sigma)
          MHprob <- MHprob - LogDensityNormalKernel(currentpara[para], Mu, Sigma)

          tf <- Transformation[para]
          if (tf == 1){
            MHprob <- MHprob + currentpara[para]
            MHprob <- MHprob - proposedpara[para]
          }
          if (tf == 2){
            temp <- exp(proposedpara[para])/(1.0 + exp(proposedpara[para]))
            MHprob <- MHprob - log((temp*(1-temp)))
            temp <- exp(currentpara[para])/(1.0 + exp(currentpara[para]))
            MHprob <- MHprob + log((temp*(1-temp)))
          }

          if (MHprob > log(runif(1))){
            Parameters[para, target] <- proposedpara[para]
            AccParameters[para] <- AccParameters[para] + 1
            Output_current[,target] = Output_proposed[,target]
            Veloglikelihood <- Veloglikelihood + ProposedloglikeVec
          }else{
            Veloglikelihood <- Veloglikelihood + CurrentloglikeVec
          }
        }else{
          if(para == Np){
            if(Imputemissing){
              Temp <- Loglikelihood_nomissing(Output_current[,target], Y[,target], Ve, Ne, Nve, Residualgroup, CurrentloglikeVec)
            }else{
              Temp <- Loglikelihood(Output_current[,target], Y[,target], Ve, Ne, Missing, Nve, Residualgroup, CurrentloglikeVec)
            }
            Currentloglike <- Temp[[1]]
            CurrentloglikeVec <- Temp[[2]]
            Veloglikelihood <- Veloglikelihood + CurrentloglikeVec
          }
        }

        if (AfterBurnin)
        {
          SampledPara[(para-1) * Nsab + CumNsab, target] <- Parameters[para,target]
        }
      }
    }

    #Update of Ve
    for(env in 1:Nve){
      proposal <- rnorm(1, Ve[env], SdforVe[env])
      Currentloglike <- Veloglikelihood[env] - 0.5 * NeNl[env] * log(Ve[env])
      if (proposal>0.0)
      {
        Proposedloglike <- Veloglikelihood[env] * Ve[env] / proposal - 0.5 * NeNl[env] * log(proposal)

        MHprob <- Proposedloglike - Currentloglike
        MHprob <- MHprob - log(proposal)
        MHprob <- MHprob + log(Ve[env])

        if (MHprob>log(runif(1))){
          Ve[env] = proposal
          AccVe[env] <- AccVe[env] + 1
          if (DoSampling) { Loglike[CumNs] <- Loglike[CumNs] + Proposedloglike }
        }else{
          if (DoSampling) { Loglike[CumNs] <- Loglike[CumNs] + Currentloglike }
        }
      }else{
        if (DoSampling) { Loglike[CumNs] <- Loglike[CumNs] + Currentloglike }
      }
      if (AfterBurnin){
        SampledVe[CumNsab,env] = Ve[env]
      }
    }

    #Update of missing Y
    if (Imputemissing){
      for (line in 1:Nmiss)
      {
        Y[Missingposition[line,1],Missingposition[line,2]] <-
          rnorm(1, Output_current[Missingposition[line,1],Missingposition[line,2]], sqrt(Ve[Residualgroup[Missingposition[line,1]]]));
      }
    }
  }#mcmc

  list(SampledPara=SampledPara, SampledVe=SampledVe, AccParameters=AccParameters, AccVe=AccVe, Loglike=Loglike, Ve=Ve)
}
